package mtr.app.asset;



import java.rmi.RemoteException;

import psdi.app.workorder.WOSet;
import psdi.app.workorder.WOSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetListenable;
import psdi.util.MXException;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;
import psdi.app.measurement.MeasurementServiceRemote;
import psdi.app.repairfacility.RepairFacilityRestriction;
import psdi.app.ticket.TicketRemote;
import psdi.mbo.HierarchicalMboSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetListenable;
import psdi.mbo.MboSetListener;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValueData;
import psdi.mbo.SqlFormat;
import psdi.security.ProfileRemote;
import psdi.server.MXServer;
import psdi.txn.MXTransaction;
import psdi.util.CombineWhereClauses;
import psdi.util.MXAccessException;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.plust.app.workorder.PlusTWOSet;
import psdi.plust.app.workorder.PlusTWOSetRemote;
import psdi.plust.app.workorder.PlusTWO;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.TreeSet;
import java.util.Vector;
import psdi.app.asset.virtual.AssetGrpDfltSetRemote;
import psdi.app.asset.virtual.AssetModifyDfltSetRemote;
import psdi.app.asset.virtual.AssetMoveDfltSetRemote;
import psdi.app.asset.virtual.AssetUserCusDfltSetRemote;
import psdi.app.common.virtual.DrillDownSetRemote;
import psdi.app.location.LocationRemote;
import psdi.app.measurement.MeasurementServiceRemote;
import psdi.app.site.SiteServiceRemote;
import psdi.mbo.HierarchicalMboSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueData;
import psdi.mbo.SqlFormat;
import psdi.security.ProfileRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.app.asset.*;



public class MTR_AssetSet extends psdi.plust.app.asset.PlusTAssetSet
implements AssetSetRemote
{
	  public MTR_AssetSet(MboServerInterface ms)
			    throws MXException, RemoteException
			  {
			    super(ms);
			  }
			  
	  

	  
	  private String originalAssetUserWhere = "";

	  public void filterByLinearAsset(MboSetRemote fltrSet) throws MXException, RemoteException {
	    if (this.originalAssetUserWhere.equals("") && !getUserWhere().equals(""))
	      this.originalAssetUserWhere = getUserWhere(); 
	    String sqlString = getSqlForFiltering(fltrSet);
	    if (sqlString != null && !sqlString.equals("")) {
	      setUserWhere(sqlString);
	      reset();
	    } 
	  }
	  
	  public String getSqlForFiltering(MboSetRemote fltrSet) throws MXException, RemoteException {
	    String sqlString = "";
	    int i = 0;
	    for (MboRemote fltr = fltrSet.getMbo(0); fltr != null; 
	      fltr = fltrSet.getMbo(++i)) {
	      if (!fltr.toBeDeleted())
	        if (!fltr.isNull("assetnum") && !fltr.isNull("assetlocsiteid")) {
	          String tmpsql = "";
	          String targettmpsql = "";
	          MboSetRemote assetSet = MXServer.getMXServer().getMboSet("ASSET", 
	              getUserInfo());
	          assetSet.setWhere("assetnum= '" + fltr.getString("assetnum") + "' and 1=1 and siteid = '" + fltr.getString("assetlocsiteid") + "'");
	          assetSet.reset();
	          MboRemote assetMbo = assetSet.getMbo(0);
	          double startOffsetVal = fltr.getDouble("startoffset");
	          double endOffsetVal = fltr.getDouble("endoffset");
	          double startMeasureConverted = fltr.getDouble("startmeasure");
	          double endMeasureConverted = fltr.getDouble("endmeasure");
	          if (assetMbo != null) {
	            String measureUnitId = assetMbo.getString("linearrefmethod.measureunitid");
	            String offsetMeasureUnitId = assetMbo.getString("linearrefmethod.offsetmeasureunitid");
	            if (!measureUnitId.equals("") && 
	              !offsetMeasureUnitId.equals("") && 
	              !measureUnitId.equals(offsetMeasureUnitId)) {
	              MeasurementServiceRemote measureService = (MeasurementServiceRemote)MXServer.getMXServer().lookup("MEASUREMENT");
	              double conversion = measureService.getConversionFactor(assetMbo
	                  .getUserInfo(), offsetMeasureUnitId, measureUnitId);
	              if (conversion > 0.0D) {
	                startOffsetVal = conversion * startOffsetVal;
	                endOffsetVal = conversion * endOffsetVal;
	              } 
	            } 
	          } 
	          //tmpsql = tmpsql + "assetnum in (select targetassetnum from assetlocrelation al where (al.sourceassetnum is not null and  al.sourceassetnum =  '" + fltr.getString("assetnum") + "' and siteid = '" + fltr.getString("assetlocsiteid") + "'  ";
	          
	          tmpsql = tmpsql + "(assetnum in (select targetassetnum from assetlocrelation al where (al.sourceassetnum is not null and  al.sourceassetnum =  '" + fltr.getString("assetnum") + "' and siteid = '" + fltr.getString("assetlocsiteid") + "'  )) ";
	          tmpsql = tmpsql + "or assetnum in (select targetassetnum from assetlocrelation al2 where (al2.sourceassetnum is not null and  al2.sourceassetnum in (select targetassetnum from assetlocrelation al where (al.sourceassetnum is not null and  al.sourceassetnum =  '" + fltr.getString("assetnum") + "' and siteid = '" + fltr.getString("assetlocsiteid") + "'  )))) ";
	          tmpsql = tmpsql + "or assetnum in (select targetassetnum from assetlocrelation al3 where (al3.sourceassetnum is not null and  al3.sourceassetnum in (select targetassetnum from assetlocrelation al2 where (al2.sourceassetnum is not null and  al2.sourceassetnum in (select targetassetnum from assetlocrelation al where (al.sourceassetnum is not null and  al.sourceassetnum =  '" + fltr.getString("assetnum") + "' and siteid = '" + fltr.getString("assetlocsiteid") + "'  ))))))) ";
	          
	          targettmpsql = targettmpsql + "assetnum in (select sourceassetnum from assetlocrelation al where (al.targetassetnum is not null and  al.targetassetnum =  '" + fltr.getString("assetnum") + "' and siteid = '" + fltr.getString("assetlocsiteid") + "'  ";
	          if (!fltr.isNull("startmeasure") && !fltr.isNull("endmeasure")) {
	            tmpsql = tmpsql + " and ( (sourcestartmeasure >= " + startMeasureConverted + " and sourcestartmeasure <= " + endMeasureConverted + ")  or  (sourceendmeasure >= " + startMeasureConverted + " and sourceendmeasure <= " + endMeasureConverted + ") or  (sourcestartmeasure <= " + startMeasureConverted + " and sourceendmeasure >= " + endMeasureConverted + ") or  (sourcestartmeasure >= " + endMeasureConverted + " and sourceendmeasure <= " + startMeasureConverted + ")) ";
	            targettmpsql = targettmpsql + " and ( (targetstartmeasure >= " + startMeasureConverted + " and targetstartmeasure <= " + endMeasureConverted + ")  or  (targetendmeasure >= " + startMeasureConverted + " and targetendmeasure <= " + endMeasureConverted + ") or  (targetstartmeasure <= " + startMeasureConverted + " and targetendmeasure >= " + endMeasureConverted + ") or  (targetstartmeasure >= " + endMeasureConverted + " and targetendmeasure <= " + startMeasureConverted + ")) ";
	          } else if (!fltr.isNull("startmeasure")) {
	            tmpsql = tmpsql + " and (sourcestartmeasure >= " + startMeasureConverted + "or sourceendmeasure >= " + startMeasureConverted + ")";
	            targettmpsql = targettmpsql + " and (targetstartmeasure >= " + startMeasureConverted + "or targetendmeasure >= " + startMeasureConverted + ")";
	          } else if (!fltr.isNull("endmeasure")) {
	            tmpsql = tmpsql + " (sourcestartmeasure <= " + endMeasureConverted + " or sourceendmeasure <= " + endMeasureConverted + ")";
	            targettmpsql = targettmpsql + " (targetstartmeasure <= " + endMeasureConverted + " or targetendmeasure <= " + endMeasureConverted + ")";
	          } 
	          if (!fltr.isNull("startyoffset") && !fltr.isNull("endyoffset")) {
	            tmpsql = tmpsql + " and ( (sourcestartyoffset >= :3 and sourcestartyoffset <= :4) or  (sourceendyoffset >= :3 and sourceendyoffset <= :4) or  (sourcestartyoffset <= :3 and sourceendyoffset >= :4) or  (sourcestartyoffset >= :4 and sourceendyoffset <= :3)) ";
	            targettmpsql = targettmpsql + " and ( (targetstartyoffset >= :3 and targetstartyoffset <= :4) or  (targetendyoffset >= :3 and targetendyoffset <= :4) or  (targetstartyoffset <= :3 and targetendyoffset >= :4) or  (targetstartyoffset >= :4 and targetendyoffset <= :3)) ";
	          } else if (!fltr.isNull("startyoffset")) {
	            tmpsql = tmpsql + " and (sourcestartyoffset >= :3 or sourceendyoffset >= :3)";
	            targettmpsql = targettmpsql + " and (targetstartyoffset >= :3 or targetendyoffset >= :3)";
	          } else if (!fltr.isNull("endyoffset")) {
	            tmpsql = tmpsql + " (sourcestartyoffset <= :4 or sourceendyoffset <= :4)";
	            targettmpsql = targettmpsql + " (targetstartyoffset <= :4 or targetendyoffset <= :4)";
	          } 
	          if (!fltr.isNull("startzoffset") && !fltr.isNull("endzoffset")) {
	            tmpsql = tmpsql + " and ( (sourcestartzoffset >= :5 and sourcestartzoffset <= :6) or  (sourceendzoffset >= :5 and sourceendzoffset <= :6) or  (sourcestartzoffset <= :5 and sourceendzoffset >= :6) or  (sourcestartzoffset >= :6 and sourceendzoffset <= :5)) ";
	            targettmpsql = targettmpsql + " and ( (targetstartzoffset >= :5 and targetstartzoffset <= :6) or  (targetendzoffset >= :5 and targetendzoffset <= :6) or  (targetstartzoffset <= :5 and targetendzoffset >= :6) or  (targetstartzoffset >= :6 and targetendzoffset <= :5)) ";
	          } else if (!fltr.isNull("startzoffset")) {
	            tmpsql = tmpsql + " and (sourcestartzoffset >= :5 or sourceendzoffset >= :5)";
	            targettmpsql = targettmpsql + " and (targetstartzoffset >= :5 or targetendzoffset >= :5)";
	          } else if (!fltr.isNull("endzoffset")) {
	            tmpsql = tmpsql + " (sourcestartzoffset <= :6 or sourceendzoffset <= :6)";
	            targettmpsql = targettmpsql + " (targetstartzoffset <= :6 or targetendzoffset <= :6)";
	          } 
	          SqlFormat sqf = new SqlFormat(tmpsql);
	          sqf.setDouble(1, fltr.getDouble("startmeasure"));
	          sqf.setDouble(2, fltr.getDouble("endmeasure"));
	          sqf.setDouble(3, fltr.getDouble("startyoffset"));
	          sqf.setDouble(4, fltr.getDouble("endyoffset"));
	          sqf.setDouble(5, fltr.getDouble("startzoffset"));
	          sqf.setDouble(6, fltr.getDouble("endzoffset"));
	          sqf.setObject(7, "ASSETFEATURE", "ASSETNUM", fltr
	              .getString("assetnum"));
	          sqf.setObject(8, "ASSETFEATURE", "SITEID", fltr
	              .getString("assetlocsiteid"));
	          sqf.setObject(9, "ASSETFEATURE", "FEATURE", fltr
	              .getString("feature"));
	          SqlFormat sqftarget = new SqlFormat(targettmpsql);
	          sqftarget.setDouble(1, fltr.getDouble("startmeasure"));
	          sqftarget.setDouble(2, fltr.getDouble("endmeasure"));
	          sqftarget.setDouble(3, fltr.getDouble("startyoffset"));
	          sqftarget.setDouble(4, fltr.getDouble("endyoffset"));
	          sqftarget.setDouble(5, fltr.getDouble("startzoffset"));
	          sqftarget.setDouble(6, fltr.getDouble("endzoffset"));
	          sqftarget.setObject(7, "ASSETFEATURE", "ASSETNUM", fltr
	              .getString("assetnum"));
	          sqftarget.setObject(8, "ASSETFEATURE", "SITEID", fltr
	              .getString("assetlocsiteid"));
	          sqftarget.setObject(9, "ASSETFEATURE", "FEATURE", fltr
	              .getString("feature"));
	          if (sqlString.equals("")) {
	            sqlString = "(" + sqf.format().toString() + ") or (" + sqftarget.format().toString() + ")))";
	          } else {
	            sqlString = sqlString + " or (" + sqf.format().toString() + ") or (" + sqftarget.format().toString() + ")))";
	          } 
	        }  
	    } 
	    if (!sqlString.equals(""))
	      sqlString = " assetnum is not null and " + sqlString; 
	    return sqlString;
	  }	  
}
