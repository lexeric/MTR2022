/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-U18
 *
 * (C) COPYRIGHT IBM CORP. 2011, 2022
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been
 * deposited with the U.S. Copyright Office.
 */

/**
 * This is the implementation of Map.js for Maximo Spatial maps.
 */

define(["dojo/main","dijit/main", "dojox/main", "dojox/html/metrics",
	"dojo/_base/declare", "dojo/parser", "dojo/ready", "dojo/on", "dojox/layout/ResizeHandle", "dojo/query",
	"dojo/dnd/Moveable","dojo/dom-attr", "dojo/dom-geometry", "dojo/dom-style", "dojo/promise/all", "dojo/when",
	"dijit/Tooltip", "dijit/_WidgetBase", "dijit/form/Button", "ibm/tivoli/fwm/mxmap/Map",
	"ibm/tivoli/fwm/mxmap/MXRecord",
	"ibm/tivoli/fwm/mxmap/impl/polyline/MaximoSpatialPolyline",
	"ibm/tivoli/fwm/mxmap/impl/point/MaximoSpatialLatLonPoint",
	"ibm/tivoli/fwm/mxmap/impl/marker/MaximoSpatialMarker",
	"ibm/tivoli/fwm/mxmap/impl/boundingbox/MaximoSpatialBoundingBox",
	"ibm/tivoli/fwm/mxmap/impl/geocoder/MaximoSpatialGeocoder",
	"ibm/tivoli/fwm/mxmap/impl/MaximoSpatialMxn", "ibm/tivoli/fwm/mxmap/impl/MaximoSpatialMover",
	"ibm/tivoli/fwm/mxmap/InfoWindow", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/symbols/SimpleFillSymbol", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/symbols/SimpleLineSymbol",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/symbols/SimpleMarkerSymbol", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/dijit/Popup",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/geometry/Extent", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/SpatialReference", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/map", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/request", "dojo/dom-construct",
	"dojo/dom-class", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/arcgis/utils", "dojo/_base/lang", "ibm/tivoli/fwm/mxmap/linear/Linear",
	"ibm/tivoli/fwm/mxmap/linear/_LinearUtil", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/Color",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/graphic",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/geometry/geometryEngine",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/toolbars/navigation",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/geometry/Point", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/geometry/Polygon", "ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/tasks/query",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/layers/FeatureLayer", "ibm/tivoli/fwm/mxmap/MaximoIntegration",
	"ibm/tivoli/fwm/mxmap/security/ValidateUrlToken", "ibm/tivoli/fwm/i18n", "ibm/tivoli/fwm/mxmap/util/PlusSToolsCommons",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/geometry/normalizeUtils",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/dijit/Legend",
	"ibm/tivoli/fwm/mxmap/LoadEsriPlugin!esri/layers/ArcGISDynamicMapServiceLayer",
],
function ( dojo, dijit, dojox, metrics, declare, parser, ready, on, ResizeHandle, query, Moveable, domAttr, domGeom, domStyle, all, when, Tooltip,
	_WidgetBase, Button, MxMap, MXRecord, MaximoSpatialPolyline, MaximoSpatialLatLonPoint, MaximoSpatialMarker,
	MaximoSpatialBoundingBox, MaximoSpatialGeocoder, MaximoSpatialMxn, MaximoSpatialMover, InfoWindow,
	SimpleFillSymbol, SimpleLineSymbol, SimpleMarkerSymbol, Popup, Extent, SpatialReference, Map,
	esriRequest, domConstruct, domClass, arcgisUtils, lang, Linear, _LinearUtil, Color, Graphic,
	geometryEngine, Navigation, Point, Polygon, Query, FeatureLayer, MaximoIntegration, ValidateUrlToken, i18n, PlusSToolsCommons, NormalizeUtils, Legend, ArcGISDynamicMapServiceLayer ) {
	return declare([MxMap], {
		validateUrlToken : null,
		refreshMapHandle : null,
		linear : null,
		latLongWkID : 4326,
		firstLayerSpatialReference : null,
		centerWithNoSpatialReference : null,
		esriFieldNumberTypes : null,
		layersVisibilityObservers: [],
		constructor : function ( options ) {
			this.providerName = "maximospatial";
			this._alreadyFixedStartingMboZoom = false;
			this.setMapDojoVersion(dojo);
			this.linear = new Linear( {
				map : this
			} );
			this.messageBoxErrorColor = "#FF0000";
			this.firstLayerTileInfo = null;
			dojo.subscribe("PlusSDeleteFeature", dojo.hitch( this, this.handlePlusSDeleteFeature ));
			dojo.subscribe("PlusSUnlinkFeature", dojo.hitch( this, this.handlePlusSUnlinkFeature ));
			
			esri.config.defaults.io.proxyUrl = dojo.config.fwm.ctxRoot + '/webclient/pluss/proxy.jsp';
			this.esriFieldNumberTypes = new Set(["esriFieldTypeSmallInteger", "esriFieldTypeInteger", "esriFieldTypeSingle", "esriFieldTypeDouble", "esriFieldTypeOID"]);
		},
		/**
		 * Publish events to a channel
		 * Needed when we need to forward Maximo dojo events to Map dojo
		 */
		publishMapEvent: function(eventType, eventParams) {
			dojo.publish(eventType, eventParams);
		},
		handlePlusSUnlinkFeature: function(action){
			console.debug("Event: plusSUnlinkFeature in Map.js - " + action);
			this.mapConf.plussIsGis = null;
			this.autoRefreshMap();
			this.hideLoadingImg();
			this.updateMapDefinitionInfoUnlinked();
			dojo.publish("unLinkFeatureEventLM",[action]);
		},
		handlePlusSDeleteFeature: function(action) {
			console.debug("Event: plusSDeleteFeature in Map.js - " + action);
			this.mapConf.plussIsGis = null;
			this.autoRefreshMap();
			this.hideLoadingImg();
			dojo.publish("unLinkFeatureEventLM",[action]);
		},
		/**
		 * Update the layer definitions after a unlink from Maximo server side
		 */
		updateMapDefinitionInfoUnlinked: function() {
			this.mapConf.plussIsGis = false;
			if (this.mapConf.currentMbo && this.mapConf.currentMbo.mxdata && this.mapConf.currentMbo.mxdata.attributes) {
				this.mapConf.currentMbo.mxdata.attributes.plussfeatureclass = null;
				this.mapConf.currentMbo.mxdata.attributes.plussisgis = false;
				//Check if needs to update layer definition
				var mapServiceName = this.mapConf.currentMbo.layerInfoData[0].serviceName;
				var layerId = this.mapConf.currentMbo.layerInfoData[0].layer.layerId;
				var mapServiceLayerConf = this.getMapConfInfoFromNameAndId(mapServiceName, layerId);
				var layerFiltered = mapServiceLayerConf.hasToFilterFeatures;
				if (layerFiltered) {
					var mapId;
					var layerInfoUrl = this.mapConf.currentMbo.layerInfoData[0].url;
					//Get Edit Tool
					var toolbarItems = this.toolbar.getToolItems() || [];
					var editTool = toolbarItems.find(function(item) {
						return item.toolName == "EditTool";
					});
					//Check if the layer is related to a Edit Tool layer
					var editToolLayer;
					var isEditToolLayerOnMap;
					if (editTool && editTool.editPanelWidget) {
						editToolLayer = editTool.editPanelWidget.findEditToolLayerByMapServerAndLayerId(layerInfoUrl );
						if  (editToolLayer && editToolLayer.id) {
							//If the edit tool layer is not on the map, the editToolLayerId will be null
							isEditToolLayerOnMap = this.map.getLayer(editToolLayer.id) ? true : false;
						}
					}
					if (isEditToolLayerOnMap) {
						mapId = editToolLayer.id;
						//If it is a Feature Layer, we will clear the feature selection
						if (editToolLayer.clearSelection) {
							editToolLayer.clearSelection();
						}
					} else {
						var mapLayer;
						//Search the layer in the Dynamic Layers first, and then Graphics Layers
						mapLayer = this.findMapLayerByUrl(this.mapConf.currentMbo.layerInfoData[0].mapServerUrl, this.map.layerIds);
						if (!mapLayer && mapServiceLayerConf.webMapDefined) {
							mapLayer = this.findMapLayerByUrl(this.mapConf.currentMbo.layerInfoData[0].mapServerUrl, this.map.graphicsLayerIds);
						}
						mapId = (mapLayer) ? mapLayer.id: null;
					}
					this.updateLayerDefinitionsFromMaximo(mapId,layerId );
				}	
			}
		},
		findMapLayerByUrl: function(url, layerIds) {
			var layerFound;
			dojo.forEach(layerIds,function(layerId) {
				var layer = this.map.getLayer(layerId);
				if (layer.url == url) {
					layerFound = layer;
				}
			}, this);
			return layerFound;
		},
		refreshFeatureLayers: function() {
			dojo.forEach(this.map.graphicLayerIds, function(layerId) {
				if (!(layerId == "providerMarkerLayer") && !(layerId == "providerHighlightLayer")) {
					var layer = this.map.getLayer(layer.id);
					layer.clearSelection();
					layer.refresh();
				}
			}, this);
		},
		/**
		 * MaximoSpatial does not support traffic layer
		 */
		allowsTrafficLayer : function () {
			return false;
		},
		/**
		 * There may be some spatial specific configurations
		 */
		_getCustomInitOptions : function () {
			if ( this.customInitialMapOptions ) {
				return this.customInitialMapOptions.spatial;
			}
			log.info( "no custom configuration" );
			return {};
		},
		// check if there is a valid configuration
		createMap : function ( options ) {
			if (window.dojox && window.dojox.html) {
				window.dojox.html.metrics = metrics;
			}
			this.maximo = new MaximoIntegration( options );
			this.linear.hideControls();
			if ( !options.mapConf.SPATIAL ) {
				console.error( "no spatial conf" );
				this.getMaximo().showMessage( "mapcontrol", "nospatialmapconf" );
			} else {
				var spatialConf = options.mapConf.SPATIAL;
				if ( spatialConf.bingMaps != true && spatialConf.openStreetMap != true
						&& ( spatialConf.mapservices == null || spatialConf.mapservices.length == 0 )
						&& !spatialConf.webMap.webMapDefined ) {
					this.getMaximo().showMessage( "plussmap", "no_mapservices_configured" );
				} else {
					if ( this.refreshMapHandle ) {
						dojo.disconnect( this.refreshMapHandle );
					}
					this.refreshMapHandle = dojo.subscribe( "refreshMapListener", dojo.hitch( this,
							function ( currentMbo ) {
								_LinearUtil().refreshNextMboView( this, currentMbo );
								this.mapConf.currentMbo = currentMbo;
								this.mapConf.plussIsGis = currentMbo.gisdata.PLUSSISGIS;
								var providerMarkerLayer = this.map.getLayer( "providerMarkerLayer" );
								if ( providerMarkerLayer ) {
									providerMarkerLayer.clear();
								}
								this.autoRefreshMap();
							} ) );
					this.inherited( arguments );
				}
			}
		},
		/**
		 * Loads the initial options for the mapstraction map creation.<Br>
		 * Returns the route url service, geocode url service, initial extent and specific spatial conf.
		 */
		_getInitOptions : function () {
			var options = {
				route : this.mapConf.route,
				geocode : this.mapConf.geocode,
				initialExtent : this._getInitialLocation(),
				lastUserLocationData : this.userSessionManager.getLastUserLocation(),
				spatial : this.mapConf.SPATIAL,
				isMobile : this.isMobile,
				defaultLenUnit : this.getDefaultLengthUnit()
			};
			return options;
		},

		_getDefaultInitialLocation : function () {
			return {};
		},
		/**
		 * Returns the geocode configuration url and rev geocode address format
		 */
		getGeoCoderConf : function () {
			var options = {
				url : this.mapConf.geocode,
				revGeocodeAddressFormat : this.mapConf.revgeocodeaddressformat
			};
			return options;
		},
		/**
		 * Esri maps is compound of several mapservices. Some of them may fail to load but the map can
		 * be used. Code tolerates failures but at the end shows a message with all mapservices that
		 * failed to load.
		 */
		_checkMapLoadedCorrectly : function () {
			var _failedLayers = this.getFailedLayers();
			if ( _failedLayers && _failedLayers.length > 0 ) {
				// plussmap,failed_loading_layer
				console.log( "_failedLayers", _failedLayers );
				var params = [
						_failedLayers[ 0 ].name, _failedLayers[ 0 ].error.message
				];
				// we use the same maximo spatial message.
				this.getMaximo().showMessage( "plussmap", "failed_loading_layer", params );
			}
		},
		/**
		 * In order to support Linked records we need to intercept the center on mbo to not only rely on
		 * X/Y but also on Featureclasses.
		 */
		centerOnMbo : function ( mboInfo, zoomlevel ) {
			// Using the MXRecord wrapper to handle mboInfo's properties
			var mxRec = new MXRecord( {
				mboInfo : mboInfo,
				map : this
			} );

			var spatialAutolocate = this._isAutolocateBasedOnSpatial( mboInfo );
			// Added a condition to only enter this if clause if the record
			// is not an LBS record. LBS records must be handled by the base method
			if ( ( ( this._isBasedOnSpatial( mboInfo ) == true ) || ( spatialAutolocate == true ) )
					&& !mxRec.useLBSData() ) {
				var fct = function ( args ) {
					try {
						var point = this._updateMboInfo( mboInfo, args );
						this._centerOnPoint( point, zoomlevel );
					} catch ( e ) {
						console.error( "No shape found in feature!", args, e );
						this.showWarningMessage( "map", "linkedfeaturenoshapefound", null );
					}
				};
				if ( spatialAutolocate == true ) {
					this._queryMapsServiceForMboGeometry( mboInfo.autolocate, dojo.hitch( this, fct ) );
				} else {
					this._queryMapsServiceForMboGeometry( mboInfo, dojo.hitch( this, fct ) );
				}
			} else {
				this.inherited( arguments );
			}

		},
		// Get the center screen point based on feature's geometry
		getFeatureCenterPoint : function ( feature ) {
			var geometry = feature.geometry;
			var point = feature.geometry;
			if ( geometry.type == 'polyline' ) {
				var len = null;
				var wkid = feature.geometry.spatialReference.wkid;
				// WKID 4326 and webmercator consider the curvature of the earth
				try {
					if ( wkid == 4326 || (geometry.spatialReference && geometry.spatialReference.isWebMercator()) ) {
						len = geometryEngine.geodesicLength( feature.geometry );
					} else {
						len = geometryEngine.planarLength( feature.geometry );
					}
					if ( len != null && len != undefined && len > 0 ) {
						point = this.linear.getPointByDistance( feature.geometry.paths[ 0 ],
							len / 2, feature.geometry.spatialReference );
						if ( point == null || point == undefined ) {
							throw "It is not possible to calculate the intermediate point for the linked feature";
						}
					} else {
						if ( typeof geometry.getExtent == 'function' && geometry.getExtent() ) {
							point = geometry.getExtent().getCenter();
						}

					}
				} catch ( e ) {
					console
							.error(
									"Error when trying to calculate the feature length using its geometry, using the first point (paths or rings) ",
									feature.geometry );
					console.error( e );
					if ( geometry.paths ) {
						var path = geometry.paths[ 0 ][ 0 ];
						point = new Point( path[ 0 ], path[ 1 ], new esri.SpatialReference(
								geometry.spatialReference ) );
					} else {
						if ( geometry.rings ) {
							var ring = geometry.rings[ 0 ][ 0 ];
							point = new Point( ring[ 0 ], ring[ 1 ], new esri.SpatialReference(
									geometry.spatialReference ) );
						}
					}
				}

			} else if (geometry.type=="polygon" ){
				point = geometry.getExtent().getCenter();
				var isPointInSideGeometry= geometryEngine.contains(geometry,point);
				if (!isPointInSideGeometry){
					point=geometryEngine.nearestCoordinate(geometry, point).coordinate;
				}		
			}
			else {
				   if ( typeof geometry.getExtent == 'function' && geometry.getExtent() ) {
					   point = geometry.getExtent().getCenter();
				   } else {
					if ( geometry.paths ) {
						var path = geometry.paths[ 0 ][ 0 ];
						point = new Point( path[ 0 ], path[ 1 ], new esri.SpatialReference(
								this.spatialReference ) );
					} else {
						if ( geometry.rings ) {
							var ring = geometry.rings[ 0 ][ 0 ];
							point = new Point( ring[ 0 ], ring[ 1 ], new esri.SpatialReference(
									this.spatialReference ) );
						}
					}
				}

			}
			return point;
		},
		/**
		 * Based on a esri feature this method converts it on a mxn.LatLonPoint
		 * 
		 * @param feature
		 * @returns
		 */
		_getLatLngFromFeature : function ( feature ) {
			if ( !feature ) {
				console.error( "feature is empty", feature );
				return null;
			}
			var point = this.getFeatureCenterPoint( feature );
			var lng = point.x;
			var lat = point.y;
			var sr = point.spatialReference.toJson();

			var point = this.latLng( lat, lng, sr );
			return point;
		},
		/**
		 * Returns the layer info for a mboname/featureclass mapping.
		 * 
		 * @param mboName
		 * @param featureclassName
		 * @returns {Array}
		 */
		_getMboObjectLayers : function ( mboName, featureclassName ) {
			var conf = this.mapConf.SPATIAL;
			var layerInfo = [];
			for ( var i in conf.linkableInfo ) {
				var service = conf.linkableInfo[ i ];
				for ( var j in service.layers ) {
					var layer = service.layers[ j ];
					if ( layer.parent == mboName && layer.child == featureclassName ) {
						layerInfo.push( {
							url : service.url + "/" + layer.layerId,
							mapServerUrl : service.url,
							layer : layer,
							serviceName : service.serviceName,
							webmapDefined: service.webmapDefined
						} );

					}
				}
			}
			return layerInfo;
		},
		/**
		 * Checks if mbo does not have a x/y but has a feature class (is linked)
		 * 
		 * @param mboInfo
		 * @returns {Boolean}
		 */
		_isBasedOnSpatial : function ( mboInfo ) {
			return ( mboInfo && mboInfo.gisdata && mboInfo.gisdata.PLUSSISGIS == true )
					|| ( mboInfo && mboInfo.gisdata && mboInfo.gisdata.FROMFC == true );
		},
		/**
		 * Checks if this mbo is autolocated by an entity that has a featureclass (is linked)
		 * 
		 * @param mboInfo
		 * @returns
		 */
		_isAutolocateBasedOnSpatial : function ( mboInfo ) {
			if ( this._isBasedOnSpatial( mboInfo ) == false ) {
				return this._isBasedOnSpatial( mboInfo.autolocate );
			}
			return false;
		},
		/**
		 * Based on a mbo it can retrieve the mxn.LatLngPoint based on a cached feature. Used by
		 * Routing.
		 * 
		 * @param mboInfo
		 * @returns
		 */
		getPointFromMboInfo : function ( mboInfo ) {
			var point = this._getLatLngFromFeature( mboInfo.FC );
			return point;
		},
		/**
		 * Get the Symbology parameter for feature's highlight from the file 'map-symbology-config.json'
		 */
		getHighlightSymbologyByGeometryType : function ( geometryType, mboInfo ) {
			var symbol = {};
			var layerConfig = null;
			if ( mboInfo != null ) {
				layerConfig = this.getSymbologyManager().getLayerConfigById(
						mboInfo.mxdata.mboName );
			} else {
				layerConfig = this.getSymbologyManager().getLayerConfigById(
						this.mapConf.records[ 0 ].mxdata.mboName );
			}
			var layerHighlightSymbology = this.getSymbologyManager().getHighlightConfigByLayer(
					layerConfig );
			if ( layerHighlightSymbology ) {
				dojo.forEach( layerHighlightSymbology, function ( geomType ) {
					if ( geomType.id != null && geomType.id != "" && geomType.id == geometryType ) {
						symbol = geomType;
					}
				} );
			}
			return symbol;

		},
		/**
		 * Method to highlight the current feature based on its geometry
		 */
		zoomToCurrentMbo : function ( jsonLayerDetails ) {
			var deferred = new dojo.Deferred();
			var scale = this.getOptimizedScaleFromLayer( jsonLayerDetails, this.map.getScale() );
			var currentRecordMgr = this.currentRecordMgr;
			if ( dojo.config.fwm.debug == true ) {
				console.log( "zoomToCurrentFeature", currentRecordMgr );
			}
			if ( currentRecordMgr ) {
				var x = currentRecordMgr.mbo.marker.point.lng;
				var y = currentRecordMgr.mbo.marker.point.lat;
				
				var promise = this.map.centerAt(new Point(x, y, this.map.spatialReference));
				promise.then(dojo.hitch(this, function() {
					var promiseZoomToScale = this.map.setScale(scale);
					promiseZoomToScale.then(dojo.hitch(this, function() {
						deferred.resolve();
					}));
				}));
			} else {
				console.error( "no feature found to zoom in!", this.currentRecordMgr.mboInfo );
				deferred.reject();
				
			}
			return deferred.promise;
		},
		/**
		 * Method to highlight the current feature based on its geometry
		 */
		highlightCurrentMbo : function ( mboInfo, queryResultInfo ) {
			if ( dojo.config.fwm.debug == true ) {
				console.log( "highlightCurrentMbo", mboInfo, queryResultInfo );
			}
			//first remove the old highlight
			this.removeMboHighligh(mboInfo);
			if ( queryResultInfo.features && queryResultInfo.features[ 0 ] ) {
				var feature = queryResultInfo.features[ 0 ];
				var symbol = null;
				var geom = null;
				if ( feature.geometry ) {
					var geoType = feature.geometry.type;
					var geometrySymbol = this.getHighlightSymbologyByGeometryType( geoType, mboInfo );
					var styleMarker = null;
					if ( geometrySymbol != null
							&& ( geometrySymbol.id === "point" || geometrySymbol.id === "multipoint" ) ) {
						symbol = new SimpleMarkerSymbol();
						symbol.setColor( new Color( JSON.parse( geometrySymbol.symbol.color ) ) );
						symbol.setOutline( new SimpleLineSymbol( SimpleLineSymbol.STYLE_NULL,
								new Color( JSON.parse( geometrySymbol.symbol.outlineColor ) ), 5 ) );
						var style = geometrySymbol.symbol.style;
						var styleMarker = null;
						switch ( style.toUpperCase() ) {
							case "SQUARE":
								styleMarker = SimpleMarkerSymbol.STYLE_SQUARE;
								break;
							case "CIRCLE":
								styleMarker = SimpleMarkerSymbol.STYLE_CIRCLE;
								break;
							case "DIAMOND":
								styleMarker = SimpleMarkerSymbol.STYLE_DIAMOND;
								break;
							default:
								styleMarker = SimpleMarkerSymbol.STYLE_CIRCLE;
								break;
						}
						symbol.setStyle( styleMarker );
					} else if ( geometrySymbol != null
							&& ( geometrySymbol.id === "line" || geometrySymbol.id === "polyline" ) ) {
						symbol = new SimpleLineSymbol( SimpleLineSymbol.STYLE_SOLID, new Color( JSON
								.parse( geometrySymbol.symbol.color ) ),
								Number( geometrySymbol.symbol.thickness ) );
					} else if ( geometrySymbol != null && geometrySymbol.id === "polygon" ) {
						symbol = new SimpleFillSymbol().setColor(
								new Color( JSON.parse( geometrySymbol.symbol.color ) ) ).setOutline(
								null );
					} else {
						symbol = new SimpleFillSymbol().setColor( new Color( [
								255, 0, 255, 0.5
						] ) ).setOutline( null );
					}
					var geom = feature.geometry;
					var graphicAttributes = mboInfo.mxdata.uid;
					var graphic = new Graphic( geom, symbol, graphicAttributes );

					mboInfo.highlightGraphic = graphic;

					var providerHighlightLayer;
					if ( this.map.getLayer( "providerHighlightLayer" ) === undefined ) {
						providerHighlightLayer = new esri.layers.GraphicsLayer( {
							id : "providerHighlightLayer"
						} );
						this.map.addLayer( providerHighlightLayer );
					} else {
						providerHighlightLayer = this.map.getLayer( "providerHighlightLayer" );
					}
					providerHighlightLayer.add( graphic );
				}
			} else {
				console.error( "no feature found to highlight!", queryResultInfo );
				throw "no feature found to highligh!";
			}
		},
		/**
		 * When we are able to load the feature classes of a mbo we cache this information to not have
		 * to query the service again next time.
		 * 
		 * @param mboInfo
		 * @param args
		 * @param callback
		 * @returns
		 */
		_updateMboInfo : function ( mboInfo, queryResultInfo, layerInfoData ) {
			if ( dojo.config.fwm.debug == true ) {
				console.log( "updatemboinfo", mboInfo, queryResultInfo );
			}
			if ( queryResultInfo.features && queryResultInfo.features[ 0 ] ) {
				var retFC = queryResultInfo.features[ 0 ];
				var spatialAutolocate = this._isAutolocateBasedOnSpatial( mboInfo );
				if ( dojo.config.fwm.debug == true ) {
					console.log( "Success", queryResultInfo );
				}
				if ( spatialAutolocate == true ) {
					mboInfo.autolocate.FC = retFC;
					mboInfo.autolocate.FROMFC = true;
				} else {
					mboInfo.FC = retFC;
					if (layerInfoData != null && layerInfoData.length > 0) {
						mboInfo.FC.layer = {id: layerInfoData[0].serviceName};
					}
					mboInfo.FROMFC = true;
				}
				if (retFC.geometry) {
					var point = this._getLatLngFromFeature( retFC );
					// Add the coorditates to a known variable in the mboInfo
					// regardless of provider, type of conversion, etc, so that the lat/lng point
					// can be retrieved from the layer records
					mboInfo.pointInCurrentSR = point;
					return point;
				} else {
					return null;
				}
				
			} else {
				console.error( "no feature found!", queryResultInfo );
				throw "no feature found!";
			}

		},
		/**
		 * check if this is a SPATIAL feature class mbo that is linked
		 */
		addMboMarker : function ( mboInfo, options, layerId ) {
			var layerInfoDataTmp = this._getLayerMappingForMbo( mboInfo );
			if ( layerInfoDataTmp != undefined ) {
				var serviceName = layerInfoDataTmp[ 0 ].serviceName;
				var sigoptionInfo = this.map.getLayer( serviceName );
				if ( ( sigoptionInfo ) && ( sigoptionInfo.sigoptions != null ) ) {
					for ( var i = 0; i < sigoptionInfo.sigoptions.length; i++ ) {
						var sigoptionInfoPosition = sigoptionInfo.sigoptions[ i ];
						if ( sigoptionInfoPosition.layerid == mboInfo.mxdata.attributes.layerId
								&& sigoptionInfoPosition.active == false ) {
							return;
						}
					}

				}
			}
			// Using the MXRecord wrapper to handle mboInfo's properties
			var mxRec = new MXRecord( {
				mboInfo : mboInfo,
				map : this
			} );

			var spatialAutolocate = this._isAutolocateBasedOnSpatial( mboInfo );
			// Added a condition to only enter this if clause if the record
			// is not an LBS record. LBS records must be handled by the base method
			if ( ( ( this._isBasedOnSpatial( mboInfo ) == true ) || ( spatialAutolocate == true ) )
					&& !mxRec.useLBSData() ) {
				// add SPATIAL logic to get coordinates.
				var fct = function ( queryResultInfo ) {
					try {
						var feature = queryResultInfo.features[ 0 ];
						this.getMaximo().isFeatureLinkedToMultipleRecords(feature,mboInfo, lang.hitch(this, function(data){
							if ( data.result == true ) {								
								var recordType = data.recordType;
								var records = data.records;
								this.showWarningMessage("plussmap", "featureLinkedToMultipeAssets", [recordType]);
								this.writeMessageInBox(this.messageDiv, 'plussmap', 'multipleRecordsLinkedToSameFeature', [records], true);
							}
						}));
						var mapServerCallback = function ( layer ) {
							var units = null;
							if ( layer && layer.units ) {
								units = layer.units;
							} else {
								units = this.map._params.units;
							}
							this.map.spatialMapManager.loadLinearLayers( this, units );
						}
						
						var layerInfoData = this._getLayerMappingForMbo( mboInfo );
						var point = this._updateMboInfo( mboInfo, queryResultInfo, layerInfoData );
						if (point) {
							this.highlightCurrentMbo( mboInfo, queryResultInfo );
							this._createMarker( mxRec, options, point, layerId );
							if ( spatialAutolocate == true ) {
								this.getMaximo().getAutoLocateLabel(
										dojo.hitch( this, function ( data ) {
											var labelText = data.label;
											var labelPosition = data.labelPosition;
											var labelFontSize = data.labelFontSize;
											if (labelText && labelPosition) {
												this.createAutoLocateLabel( labelText, labelPosition,
														labelFontSize, queryResultInfo );
											}
											
										} ) );
							}
						} else {
							this.showWarningMessage( "map", "linkedfeaturenoshapefound", null );
						}
						
						if ( layerInfoData ) {
							var url = layerInfoData[ 0 ].mapServerUrl;
							this._getMapServiceInfo( url, dojo.hitch( this, mapServerCallback ) );
						} else {
							dojo.publish( "startupToolbarMapInit", [] );
						}

					} catch ( e ) {
						console.error( "No feature found!", queryResultInfo, e );
						this.showWarningMessage( "map", "linkedfeaturenofeature", null );
					}
				};
				if ( spatialAutolocate == true ) {
					this._queryMapsServiceForMboGeometry( mboInfo.autolocate, dojo.hitch( this, fct ) );
				} else {
					this._queryMapsServiceForMboGeometry( mboInfo, dojo.hitch( this, fct ) );
				}

			} else {
				this.inherited( arguments );
			}
		},
		getLayerInfoData : function ( currentMbo ) {
			this._getLayerMappingForMbo( currentMbo );
		},
		_getLayerMappingForMbo : function ( mboInfo ) {
			var layerInfoData = null;
			if (mboInfo)
			{
				if (mboInfo.gisdata && mboInfo.gisdata.PLUSSISGIS){
					layerInfoData = this._getMboObjectLayers( mboInfo.mxdata.mboName,mboInfo.mxdata.attributes.plussfeatureclass );
				} else if (mboInfo.autolocate){
					console.info( "autoLocaleMbo:", mboInfo.autolocate.mxdata.mboName);
					layerInfoData = this._getMboObjectLayers( mboInfo.autolocate.mxdata.mboName, mboInfo.autolocate.mxdata.attributes.plussfeatureclass);	
				} else {
					layerInfoData = this._getMboObjectLayers( mboInfo.mxdata.mboName,mboInfo.mxdata.attributes.plussfeatureclass );								
				}
				
				console.info( "layerInfoData:", layerInfoData);

				if ( !layerInfoData || layerInfoData.length == 0 ) {
					// tries with the extendsMboName (in case of views)
					layerInfoData = this._getMboObjectLayers( mboInfo.mxdata.extendsMboName, mboInfo.mxdata.attributes.plussfeatureclass );
					if ( !layerInfoData || layerInfoData.length == 0 ) {
						console.debug( "no layer mapping info for this mbo", mboInfo.mxdata.extendsMboName,	mboInfo.mxdata.attributes.plussfeatureclass, mboInfo );
						return;
					}
				}
				if ( layerInfoData.length > 1 ) {
					console.warn( "more than one layer mapping ", mboInfo.mxdata.mboName, mboInfo.mxdata.attributes.plussfeatureclass, layerInfoData );
				}
				
				mboInfo.layerInfoData = layerInfoData;	
			}
			
			return layerInfoData;
		},
		/**
		 * Method to get the Layer infos, it creates a cache to reduce the number of requests
		 * Parameters: layerObject: The layer object, containing the layerInfos and the Map server URL
		 * layerId - The layer id if you need infos about the layers inside the Map Server, which will
		 * use the Map Server url + layer id (MapServer/layerId), if you need infos about the Map
		 * Server, just pass null successCallback - The success callback function errCallback- The error
		 * callback function
		 */
		getLayerAttributes : function ( layerObject, layerId, successCallback, errCallback ) {
			if ( layerId != null && layerId != undefined ) {
				if ( !layerObject || !layerObject.layerInfos ) {
					console.error( "error getting layerInfos from layer: ", layerObject );
					if ( errCallback ) {
						errCallback();
					}
				} else {
					var layerInfos = layerObject.layerInfos;
					var layerInfo = null;
					for ( var i = 0; i < layerInfos.length; i++ ) {
						if ( layerInfos[ i ].id === layerId ) {
							layerInfo = layerInfos[ i ];
						}
					}
					if ( !layerInfo.layerAttributes ) {
						var layerUrl = layerObject.url + "/" + layerId;
						this._getMapServiceInfo( layerUrl, dojo.hitch( this, function ( attributes ) {
							layerInfo.layerAttributes = attributes;
							if ( successCallback ) {
								successCallback( layerInfo.layerAttributes );
							}
						} ), errCallback );
					} else {
						if ( successCallback ) {
							successCallback( layerInfo.layerAttributes );
						}
					}
				}
			} else {
				if ( !layerObject.layerAttributes ) {
					var layerUrl = layerObject.url;
					if (layerObject.isFeatureCollection) {
						successCallback(layerObject);
					} else if ( layerUrl == null || layerUrl == undefined ) {
						console.error( "error getting the layerUrl from layer: ", layerObject );
						if ( errCallback ) {
							errCallback();
						}
					} else {
						this._getMapServiceInfo( layerUrl, dojo.hitch( this, function ( attributes ) {
							layerObject.layerAttributes = attributes;
							if ( successCallback ) {
								successCallback( layerObject.layerAttributes );
							}
						} ), errCallback );
					}
				} else {
					if ( successCallback ) {
						successCallback( layerObject.layerAttributes );
					}
				}
			}

		},
		_getMapServiceInfo : function ( url, successCallback, errCallback ) {
			var requestHandle = esriRequest( {
				"url" : this.validateUrlToken.addTokenIfApplicable( url ),
				"content" : {
					"f" : "json"
				},
				"callbackParamName" : "callback"
			} );
			requestHandle.then( successCallback, lang.hitch( this, function ( error ) {
				console.error( "No MapServer layer info url: ", url );
				if ( errCallback ) {
					errCallback();
				}
			} ) );
		},
		/**
		 * Based on a mboinfo it queries for its feature class based on the MaximoSpatial configuration
		 * between the Mbo and the feature classe (gisobject)
		 * 
		 * @param mboInfo
		 * @param callback
		 * @param errCb
		 */
		_queryMapsServiceForMboGeometry : function ( mboInfo, callback, errCb ) {
			// if it's cached
			if ( mboInfo.FROMFC == true ) {
				callback( {
					features : [
						mboInfo.FC
					]
				} );
				return;
			}

			// tries first with the mboName
			var layerInfoData = this._getLayerMappingForMbo( mboInfo );
			if ( layerInfoData && layerInfoData[0].layer.linkableColumnsJson.length > 0 ) {
				this._getMBOGeometry( layerInfoData, [
					mboInfo
				], callback, errCb );
			} else {
				console.error( "No layer info" );
				if ( errCb ) {
					errCb();
				}
			}

		},
		_checkIfAnyFeaturedClass : function ( recs ) {
			for ( var i in recs ) {
				var stop = recs[ i ];
				var mxrec = new MXRecord( {
					mboInfo : stop,
					map : this.map
				} );

				if ( mxrec.hasSPATIALCoordinates()
						|| ( mxrec.hasGISCoordinates() == false && mxrec.hasAutolocateSpatialData() == true ) ) {
					return true;
				}
			}
		},
		showAllMboRecords : function ( records, markerOptions, zoom ) {
			if ( !records || records.length == 0 || this.mapConf.isOpenMap == true ) {
				return;
			}
			var callback = function ( mboInfoArray, totalErrors ) {
				console.log( "calledback", mboInfoArray, totalErrors );
				for ( var index in records ) {
					var mxRec = new MXRecord( {
						mboInfo : records[ index ],
						map : this
					} );
					if ( mxRec.hasAnyCoordinates() == true ) {
						// this.map.addMboToLayerManager(this.mboInfo,
						// markerOptions);
						this.addMboToLayerManager( records[ index ], markerOptions );
					} else {
						console.warn( "Mbo with no GIS info ", records[ index ] );
					}
				}
				if ( zoom == true ) {
					this.autoCenterAndZoom();
				}
			};
			if ( this._checkIfAnyFeaturedClass( records ) == true ) {
				this.queryMultipleRecordsAtOnce( records, dojo.hitch( this, callback ), dojo.hitch(
						this, callback ) );
			} else {
				dojo.hitch( this, callback )( [] );

			}
		},
		filterRecordsInMapView : function ( mboArray, callback, errCb ) {
			var esriMap = this.getProviderMap();
			this.queryMultipleRecordsAtOnce( mboArray, callback, errCb, esriMap.extent );
		},
		queryMultipleRecordsAtOnce : function ( mboArray, callback, errCb, onRegionGeometry ) {

			var queryHash = {};
			var totalUrls = 0;
			for ( var i = 0; i < mboArray.length; i++ ) {
				var mboInfo = mboArray[ i ];
				var spatialAutolocate = this._isAutolocateBasedOnSpatial( mboInfo );
				if ( this._isBasedOnSpatial( mboInfo ) == true || spatialAutolocate == true ) {
					var refMbo = mboInfo;
					if ( spatialAutolocate == true ) {
						refMbo = mboInfo.autolocate;
					}
					console.log( "mbo ", mboInfo );
					var layerInfoData = this._getLayerMappingForMbo( refMbo );
					if ( !layerInfoData ) {
						console.error( "No layer info" );
						if ( errCb ) {
							errCb();
						}
						return;
					}
					for ( var j = 0; j < layerInfoData.length; j++ ) {
						if ( queryHash[ layerInfoData[ j ].url ] == null ) {
							totalUrls++;
							queryHash[ layerInfoData[ j ].url ] = {
								info : layerInfoData[ j ],
								refMbos : [],
								mbos : []
							};
						}
						queryHash[ layerInfoData[ j ].url ].refMbos.push( refMbo );
						queryHash[ layerInfoData[ j ].url ].mbos.push( mboInfo );
					}
				}
			}
			var allInRange = [];
			var totalErrors = [];
			var accumulate = function ( url, mbos, error ) {
				totalUrls--;
				console.log( "accumulate", url, mbos, error, totalUrls );
				allInRange = allInRange.concat( mbos );
				totalErrors.push( {
					error : error,
					url : url
				} );
				if ( totalUrls == 0 ) {
					callback( allInRange, totalErrors );
				}
			};
			for ( var layerURL in queryHash ) {
				this.queryAndCache( layerURL, queryHash, dojo.hitch( this, accumulate ),
						onRegionGeometry );

			}

		},

		queryAndCache : function ( layerURL, queryHash, callback, regionGeometry ) {
			var layerInfoData = queryHash[ layerURL ].info;
			console.log( "URL ", layerURL, layerInfoData );

			var matchFCAttributeNames = layerInfoData.layer.linkableColumnsJson;
			var matchMBOAttributeNames = layerInfoData.layer.mboColumns;
			var queryTask, query;
			layerURLQuery = this.validateUrlToken.addTokenIfApplicable( layerURL );
			queryTask = new esri.tasks.QueryTask( layerURLQuery );
			query = new esri.tasks.Query();
			query.outSpatialReference = this.map.spatialReference;
			query.returnGeometry = true;
			if ( regionGeometry != null ) {
				query.geometry = regionGeometry;
			}
			query.spatialRelationship = esri.tasks.Query.SPATIAL_REL_CONTAINS;
			query.outFields = [
				'*'
			];
			query.where = this._createWhereClause( queryHash[ layerURL ].refMbos,
					matchFCAttributeNames, matchMBOAttributeNames );

			var fct = function ( args ) {
				var refMbos = queryHash[ layerURL ].refMbos;
				console.log( "args", args, refMbos, layerURL );
				var mbos = [];
				for ( var l = 0; l < args.features.length; l++ ) {
					var feature = args.features[ l ];
					// find mbo

					// If the route contains more than one instance of the same mbo,
					// we need to return all of them so the feature class (.FC property)
					// can be appended
					var mbosFound = this._getRefMbosOfFeature( refMbos, feature.attributes,
							matchFCAttributeNames, matchMBOAttributeNames );
					if ( mbosFound.length == 0 ) {
						console.log( "cannot find the mbo reference for feature", feature );
						console.log( "in mbos ", refMbos );
					}
					var me = this;
					dojo.forEach( mbosFound, function ( mbo ) {
						var whereClause = me._createWhereClause( [
							mbo
						], matchFCAttributeNames, matchMBOAttributeNames );
						console.log( "wclause was ", whereClause );
						console.log( "for         ", mbo );
						var _arg = {
							features : [
								feature
							]
						};
						me._updateQueryResultCache( layerURL, whereClause, _arg );
						mbos.push( mbo );
						mbo.FC = feature;
						mbo.FROMFC = true;
					} );
				}
				callback( layerURL, mbos );
			};
			var errfct = function ( error ) {
				console.error( "Error querying", error );
				callback( layerURL, [], error );
			};
			queryTask.execute( query, dojo.hitch( this, fct ), dojo.hitch( this, errfct ) );
		},

		_getRefMbosOfFeature : function ( _refMbos, attributes, matchFCAttributeNames,
				matchMBOAttributeNames, aliases ) {
			// If the route contains more than one instance of the same mbo,
			// we need to return all of them so the feature class (.FC property)
			// can be appended
			var mbosFound = [];
			for ( var k = 0; k < _refMbos.length; k++ ) {
				var m = _refMbos[ k ];
				console.log( "mm ", m, aliases );
				var match = false;
				for ( var ii in matchFCAttributeNames ) {
					var fcAttr = matchFCAttributeNames[ ii ];
					var attributeValue = aliases ? attributes[aliases[fcAttr.name]] : attributes[ fcAttr.name ];
					if ( m.mxdata.attributes[ matchMBOAttributeNames[ ii ].toLowerCase() ] == attributeValue ) {
						match = true;
					} else {
						match = false;
						break;
					}
				}
				if ( match == true ) {
					mbosFound.push( m );
				}
			}
			return mbosFound;
		},
		_getMBOGeometry : function ( layerInfoData, mboInfoArray, callback, errCb, index ) {
			if ( !index ) {
				index = 0;
			}
			var currentLayerInfoData = layerInfoData[ index ];
			var layerURL = currentLayerInfoData.url;
			if (currentLayerInfoData.layer.linkableColumnsJson[0].error == true) {
				var error = currentLayerInfoData.layer.linkableColumnsJson[0];
				if (this.messageDiv) {
					this.writeMessageInBox( this.messageDiv, error.group, error.key, error.params, true );
				} 
				if (errCb) {
					errCb()
				}
				return;
			} else {
				var matchFCAttributeNames = currentLayerInfoData.layer.linkableColumnsJson;
			}
			var matchFCAttributeNames = currentLayerInfoData.layer.linkableColumnsJson;
			var matchMBOAttributeNames = currentLayerInfoData.layer.mboColumns;
			var webmapDefined = currentLayerInfoData.webmapDefined;
			/*
			 * if web map is enabled in Map Manager, then using queryTask will not work
			 */
			if ( this.mapConf.SPATIAL.webMap && this.mapConf.SPATIAL.webMap.webMapDefined ) {
				webmapDefined = true;
			}
			var queryTask, query;
			layerURL = this.validateUrlToken.addTokenIfApplicable( layerURL );
			queryTask = new esri.tasks.QueryTask( layerURL );
			query = new esri.tasks.Query();
			/*
			 * if the map is already created, use the map spatial reference and return all fields if
			 * not, use latitude/longitude
			 */
			if ( this.map ) {
				query.outSpatialReference = this.map.spatialReference;
			} else {
				if ( this.firstLayerSpatialReference ) {
					query.outSpatialReference = this.firstLayerSpatialReference;
				} else {
					query.outSpatialReference = new SpatialReference( this.latLongWkID );
				}
			}
			query.outFields = [
				'*'
			];
			query.returnGeometry = true;
			query.where = this._createWhereClause( mboInfoArray, matchFCAttributeNames,
					matchMBOAttributeNames );
			if ( dojo.config.fwm.debug == true ) {
				console.info( 'getting mbo with query', query.where );
				console.info( 'On layer ', layerURL );
			}
			var whereClause = query.where;
			var systemRecord = mboInfoArray[ 0 ].mxdata.attributes[ "systemRecord" ];
			/*
			 * queryCacheKey contains the where cluase, if the map if already created if not, contains
			 * the where clause and the wkid of Latitude Longitude
			 * 
			 * This was done to be able to query the mbo geometry before the map was created, store the
			 * result in lat/long, and not use the same cache when we query later using the map's
			 * spatialReference
			 */
			var queryCacheKey;
			
			if (!this.firstLayerSpatialReference && !this.map) {
				queryCacheKey = query.where + " : ( wkid: " + this.latLongWkID + " )";
			} else {
				queryCacheKey = query.where;
			}				
			
			if ( systemRecord == "ARCGIS" ) {
				if ( this._isInCache( layerURL, queryCacheKey ) == true ) {
					callback( this._queryCache[ layerURL ][ queryCacheKey ].results );
					return;
				}

				if ( this._hasRequestedAlready( layerURL, queryCacheKey ) == true ) {
					this._updateRequestCache( layerURL, queryCacheKey, callback, errCb );
					return;
				}
			}
			this._updateRequestCache( layerURL, queryCacheKey, callback, errCb );
			var fct = function ( args ) {
				if ( this.messageDiv ) {
					this.writeMessageInBox( this.messageDiv, "plussmap", "queryTaskCompleted" );
				}
				if ( !args.features || !args.features[ 0 ] ) {
					index++;
					if ( index < layerInfoData.length ) {
						console.log( "trying next layer", index );
						this._getMBOGeometry( layerInfoData, mboInfoArray, callback, errCb, index );
					} else {
						var err = {
							errormsg : "no feature found for '" + queryCacheKey + "' on " + layerURL,
							details : {
								whereClause : whereClause,
								layerURL : layerURL,
								layerInfoData : layerInfoData
							}
						};
						this._triggerQueryResultError( layerURL, queryCacheKey, args, err );
					}
				} else {
					args.features = dojo.map(args.features, function(featureInfoFromServer) {
						var feature = null;
						if (featureInfoFromServer.geometry && !featureInfoFromServer.geometry.type) {
							var geometry = PlusSToolsCommons.createGeometry(args.geometryType, featureInfoFromServer.geometry, args.spatialReference );
							feature = new Graphic(geometry, null, featureInfoFromServer.attributes );
						} else {
							feature = featureInfoFromServer;
						}
						
						return feature;
					});
					
					this._updateQueryResultCache( layerURL, queryCacheKey, args );

					while ( this._queryRequestCache[ layerURL ][ queryCacheKey ].reqs.length > 0 ) {
						if ( dojo.config.fwm.debug == true ) {
							console.log( "Calling reqs",
									this._queryRequestCache[ layerURL ][ queryCacheKey ].reqs.length );
						}
						var ff = this._queryRequestCache[ layerURL ][ queryCacheKey ].reqs.pop();
						ff.success( args );
					}
				}

			};
			var errfct = function ( args ) {
				console.error( "Error querying for spatial feature class", args );
				var err = {
					errormsg : "Error querying for spatial feature class"
				};
				if ( this.messageDiv ) {
					this.writeMessageInBox( this.messageDiv, "plussmap", "rest_service_error", [
						args.message
					], true );
				}
				this._triggerQueryResultError( layerURL, whereClause, args, err );

			};
			
			var wkid;
			if (query.outSpatialReference.wkid) {
				wkid = query.outSpatialReference.wkid;
			} else {
				wkid = query.outSpatialReference;
			}
			
			var tokenIndex = queryTask.url.indexOf("?token=");
			var token = null;
			if (tokenIndex > -1) {
				token = queryTask.url.slice(tokenIndex + "?token=".length  );
			}
			
			var urlWithouToken = this.validateUrlToken.removeTokenParameterIfExists(queryTask.url);
			if(this.mapConf.alwaysUseProxy) {
				urlWithouToken = esriConfig.defaults.io.proxyUrl + '?' + urlWithouToken;
			}
			var queryURL = 
				urlWithouToken 
				+ "/query"
				+ "?where=" + query.where 
				+ "&spatialRel=" + query.spatialRelationship
				+ "&outFields=" + query.outFields[0]
				+ "&returnGeometry=true&outSR=" + wkid
				+ "&f=json";
			if (token) {
				queryURL = queryURL + "&token=" + token;
			}
			
			var xhrArgs = {
				url: queryURL,
				content:{},
				timeout: 10000,
				handleAs: "json",
				headers: {
					'X-Requested-With': null,
				},
				preventCache: true,
				load: dojo.hitch( this, fct ),
				error: dojo.hitch( this, errfct ),
			};
			dojo.xhrGet(xhrArgs);
				
			if ( this.messageDiv ) {
				this.writeMessageInBox( this.messageDiv, "plussmap", "executingQueryTask" );
			}
		},

		_createWhereClause : function ( mboInfoArray, matchFCAttributeJson, matchMBOAttributeNames ) {
			console.log( mboInfoArray );
			var query = "";
			for ( var j = 0; j < mboInfoArray.length; j++ ) {
				var mboInfo = mboInfoArray[ j ];
				var queryForOneMbo = "";
				for ( var i = 0; i < matchFCAttributeJson.length; i++ ) {
					var attrJson = matchFCAttributeJson[ i ];
					var attr = attrJson.name;
					var attributeType = attrJson.type;
					var isAttributeTypeNUmber = this.esriFieldNumberTypes.has(attributeType);
					var strAdd = isAttributeTypeNUmber ? "" : '\'';
					var value = mboInfo.mxdata.attributes[ matchMBOAttributeNames[ i ].toLowerCase() ];

					if ( value == null || value == undefined ) {
						console.error( "No Mbo Matching Attribute: ", mboInfo.mxdata, e );
						this.showWarningMessage( "map", "linkedfeaturenomboattribute", null );
						return;
					}
					if ( isNaN( value ) ) {
						value = value.split( "'" ).join( "''" );
						if ( attrJson.type != "esriFieldTypeGlobalID" && attrJson.type != "esriFieldTypeGUID" ) {
							value = value.toUpperCase();
							attr = "Upper(" + attr + ")";
						}

					}

					// Replace single apostrophes for double apostrophes
					if ( value.length == 0 ) {
						queryForOneMbo += attr + ' is null AND '; // empty strings
						// from
						// Maximo are null in the database
					} else {
						// Defect 55163 - Some Work Orders (Changes, Releases etc) and Tickets (SR,
						// Incidents etc)
						// with linked feature are not displayed into map tab.
						// Cannot decide whether or not to add single quotes based on the field value.
						// The decision needs to be made based on the field type, but since we do not
						// have access to the field type (it would be possible only by changing Spatial
						// code)
						// we always include single quotes around the value. Warning: It may break when
						// using a numeric linked field and a database that is strict about field types
						// (DB2)
						// if (isNaN(value))
						// {
						queryForOneMbo += attr + '=' + strAdd + value + strAdd + ' AND ';
						// }
						// else
						// {
						// queryForOneMbo += attr + '=' + value + ' AND ';
						// }
					}
				}
				if ( queryForOneMbo.length > 0 ) {
					queryForOneMbo = queryForOneMbo.substr( 0, queryForOneMbo.length - 5 );
					if ( query.length > 0 ) {
						query += " OR ";
					}
					query += "(";
					query += queryForOneMbo;
					query += ")";
				} else {
					console.error( "no matching attributes", mboInfo, matchFCAttributeNames,
							matchMBOAttributeNames );
				}

			}
			return query;
		},
		/**
		 * Checks if we have the results in cache
		 * 
		 * @param layerURL
		 * @param whereClause
		 * @return true if it's in cache
		 */
		_isInCache : function ( layerURL, whereClause ) {
			if ( this._queryCache[ layerURL ] ) {
				if ( this._queryCache[ layerURL ][ whereClause ] ) {
					if ( ( this._queryCache[ layerURL ][ whereClause ]._timestamp - new Date()
							.getTime() ) < this._expiringCache ) {
						this._queryCache[ layerURL ][ whereClause ]._hitTimes++;
						console.log( "Cache hit!",
								this._queryCache[ layerURL ][ whereClause ]._hitTimes );
						return true;
					} else {
						console.info( "expiring cahce for " + whereClause );
						this._queryCache[ layerURL ][ whereClause ] = null;
					}
				}
			}
			return false;
		},
		/**
		 * Updates the cache for query results
		 * 
		 * @param layerURL
		 * @param whereClause
		 * @param results
		 */
		_updateQueryResultCache : function ( layerURL, whereClause, results ) {
			if ( !this._queryCache[ layerURL ] ) {
				this._queryCache[ layerURL ] = {};
			}
			this._queryCache[ layerURL ][ whereClause ] = {
				results : results,
				_hitTimes : 0,
				_timestamp : new Date().getTime()
			};
		},
		/**
		 * Buffer sequenced requests
		 * 
		 * @param layerURL
		 * @param whereClause
		 * @param callback
		 * @param errCb
		 */
		_hasRequestedAlready : function ( layerURL, whereClause ) {
			if ( this._queryRequestCache[ layerURL ]
					&& this._queryRequestCache[ layerURL ][ whereClause ] != null ) {
				return true;
			}
			return false;
		},
		_updateRequestCache : function ( layerURL, whereClause, callback, errCb ) {
			if ( !this._queryRequestCache[ layerURL ] ) {
				this._queryRequestCache[ layerURL ] = {};
			}
			if ( !this._queryRequestCache[ layerURL ][ whereClause ] ) {
				this._queryRequestCache[ layerURL ][ whereClause ] = {
					reqs : []
				};
			}
			this._queryRequestCache[ layerURL ][ whereClause ].reqs.push( {
				success : callback,
				error : errCb
			} );
		},
		/**
		 * If any requests where buffered we need to trigger the error callback
		 */
		_triggerQueryResultError : function ( layerURL, whereClause, args, err ) {
			while ( this._queryRequestCache[ layerURL ][ whereClause ].reqs.length > 0 ) {
				var ff = this._queryRequestCache[ layerURL ][ whereClause ].reqs.pop();
				if ( ff.error ) {
					ff.error( err, args );
				} else {
					console.log( err );
				}
			}
		},
		_queryCache : {},
		_queryRequestCache : {},
		_expiringCache : 30000,
		getInitialLocationCustomInfo : function () {
			var esriMap = this.getProviderMap();
			return {
				extentData : {
					wkid : esriMap.spatialReference.wkid,
					wkt : esriMap.spatialReference.wkt,
					xmin : esriMap.extent.xmin,
					xmax : esriMap.extent.xmax,
					ymax : esriMap.extent.ymax,
					ymin : esriMap.extent.ymin

				}
			};
		},
		_setDefaultLocation : function ( location ) {
			var esriMap = this.getProviderMap();
			if ( esriMap.extentInitiallySet != true && location && location.lat && location.lng ) {
				console.log( "[Map] setDefaultLocation", location );
				var spatialReference = (esriMap.layerIds[0]) ? esriMap.getLayer(esriMap.layerIds[0]).spatialReference : null;
				var latLng = this.latLng( location.lat, location.lng, spatialReference );
				this.setCenterAndZoom( latLng, location.level );
			}
		},
		_resize : function () {
		
			if ( !this.height ) {
				h = '100%';
			} 

			this.inherited( arguments );
		},
		_alreadyFixedStartingMboZoom : null,
		_zoomToCurrentMboRec : function ( initialLocation ) {
			if ( this._alreadyFixedStartingMboZoom != true ) {
				var handler;
				var counter = 0;
				var fct = dojo.hitch( this, function () {
					counter++;
					if ( this.state.updating != true || counter > 100 ) {
						this.currentRecordMgr.centerAndZoom( initialLocation.level );
					} else {
						setTimeout( fct, 300 );
					}
					dojo.unsubscribe( handler );
				} );
				var h2;
				var addListener = dojo.hitch( this, function () {
					dojo.unsubscribe( h2 );
					handler = dojo.subscribe( "onESRIReposition", fct );
				} );
				h2 = dojo.subscribe( this.events.mapLoaded, addListener );
			}
			this.inherited( arguments );

		},

		/* _MapProvider implementation start */

		_init : function ( element, options ) {
			var def = new dojo.Deferred();
			this.element = element;

			try {
				this.validateUrlToken = new ValidateUrlToken( this );
				/*
				 * Messages div
				 */

				if ( this.mapConf.SPATIAL.showDebugMessages || dojo.config.fwm.debug == true ) {
					this.createMessageBox();
				}

				esriConfig.defaults.io.alwaysUseProxy = this.mapConf.alwaysUseProxy;
				esriConfig.defaults.io.proxyUrl = dojo.config.fwm.servletBase + "/pluss/proxy.jsp";
				if (this.mapConf.alwaysUseProxy) {
					esriConfig.defaults.io.corsDetection = false;
				}
				

				if ( this.mapConf.esriDefaultTimeout ) {
					esriConfig.defaults.io.timeout = this.mapConf.esriDefaultTimeout;
				}

				this.validateUrlToken.initTokenExpiretime( this.mapConf );

				var hasWebMap = false;
				if ( ( options.spatial.webMap ) && ( options.spatial.webMap.webMapDefined ) ) {
					hasWebMap = true;
				}

				// we can assure that dojo is loaded in here, that's
				// why dojo.require is not outside this block

				this._connections = [];

				var me = this;

				// prefetch openstreetmap dojo layers
				var mapInitialExtent = null;

				var popupOptions = {
					fillSymbol : new SimpleFillSymbol( SimpleFillSymbol.STYLE_SOLID,
							new SimpleLineSymbol( SimpleLineSymbol.STYLE_SOLID, new dojo.Color( [
									255, 0, 0
							] ), 2 ), new dojo.Color( [
									255, 255, 0, 0.25
							] ) ),
					markerSymbol : new SimpleMarkerSymbol( {
						"color" : [
								255, 0, 191, 100
						],
						"size" : 12,
						"angle" : -30,
						"xoffset" : 0,
						"yoffset" : 0,
						"type" : "esriSMS",
						"style" : "esriSMSCircle",
						"outline" : {
							"color" : [
									255, 0, 191
							],
							"width" : 1,
							"type" : "esriSLS",
							"style" : "esriSLSSolid"
						}
					} )
				};
				var popup = new Popup( popupOptions, dojo.create( "div" ) );

				var mapOpts = {
					isZoomSlider : true,
					isPanArrows : false,
					nav : false,
					logo : false,
					infoWindow : popup,

					// In order to resize, the spatialReference must be known beforehand
					// Thefore, autoResizing should be disabled
					autoResize : false,

					resizeDelay : 100,
					showLabels: true
				};
				// Deferred object for the map center calculation
				var deferredMapCenter = new dojo.Deferred();
				if ( this.mapConf.isPreviewMobile ) {
					// Limit the zoom if it is Preview Offline Map Action
					var initZoom = this.mapConf.initialLocation.initZoom;
					mapOpts.minZoom = initZoom;
				}
				
				// If in Map Manager, we won't try to get the map center before creating the map
				if ( this.mapConf.isInMapManager ) {
					deferredMapCenter.resolve();
				} else {

					/*
					 * extentInitialSet will be true if we find linked Mbo, Tool Persistance extent or
					 * session last user location
					 */
					this.extentInitiallySet = false;
					var lastExtentDeferred = new dojo.Deferred();
																						
					// Check if the last user location is saved
					var lastUserLocation = this._getLastUserLocation( options );
					if ( lastUserLocation ) {
						this.hasLastUserLocation = true;
						lastExtentDeferred.resolve( lastUserLocation );
					} else {
						function getMapInitialExtentFromToolsPersistanceInfo( toolsJson ) {
							if ( !toolsJson || !toolsJson.saveMapExtent ) {
								return;
							}

							return new esri.geometry.Extent( toolsJson.mapExtent );
						}
						var persistedExtent = getMapInitialExtentFromToolsPersistanceInfo( this.toolsJson );

						lastExtentDeferred.resolve( persistedExtent );
					}

					var mapMboCenterPromise = new dojo.Deferred();

					/*
					 * If doesn't have Web Map configured,the Mbo center position is calculated now
					 * otherwise it will be calculated after the web map is created
					 */
					if ( !hasWebMap ) {
						if ( this.mapConf.SPATIAL.openStreetMap || this.mapConf.SPATIAL.bingMaps ) {
							var firstLayerSpatialReference = new SpatialReference( {
								"wkid" : 102100
							} );
						} else if ( options.spatial.mapservices[ 0 ] ) {
							// Get the mbo center
							var layerURL = options.spatial.mapservices[ 0 ].url;
							var firstLayerSpatialReference = this.findLayerSpatialReference( layerURL );
						}
						when( firstLayerSpatialReference, dojo.hitch( this,
								function ( spatialReference ) {
									this.firstLayerSpatialReference = spatialReference;
									this._getMapInitialPosition().then(
											dojo.hitch( this, function ( center ) {
												mapMboCenterPromise.resolve( center );
											} ) );
								} ) );
					}

					// Using mbo center and last extent, set the map opts
					all( {
						lastExtent : lastExtentDeferred.promise,
						center : mapMboCenterPromise
					} ).then(
							dojo.hitch( this, function ( results ) {
								var setOptionsReturn = this.setMapOptsInitialPosition( results.center,
										results.lastExtent, options, mapOpts );
								when( setOptionsReturn, function () {
									deferredMapCenter.resolve();
								} );
							} ) );

					this.centerWithNoSpatialReference = false;

				}

				var geoSvcData = me.mapConf.geometryServiceUrl;
				if ( geoSvcData ) {
					try {
						me.esriGeometryService = new esri.tasks.GeometryService( geoSvcData );
					} catch ( e ) {
						console.warn( "[MaximoSpatial] Error creating geometry service for data",
								geoSvcData );
					}
				}

				/** ESRI Maps always break with right to left languages.* */
				dojo.style( element, "direction", "ltr" );

				console.log( "[Check to see what map type to create]" );
				if ( this.mapConf.SPATIAL.webMap.webMapDefined ) {
					var webMapID = this.mapConf.SPATIAL.webMap.webMapID;
					console.log( "[Create Web Map Started] with Web Map ID: " + webMapID );

					var createMapOptions = {
						mapOptions : mapOpts,
						usePopupManager : true, // since version 3.10
						// bingMapsKey: bingMapsKey,
						geometryServiceURL : geoSvcData,
						ignorePopups : true
					};

					var wbmapUrl = "https://www.arcgis.com/sharing/content/items/" + webMapID + "/data";
					if ( this.mapConf.SPATIAL.webMap.arcGISPortalEnabled ) {
						arcgisUtils.arcgisUrl = this.mapConf.SPATIAL.webMap.PORTALURL;
						wbmapUrl = this.mapConf.SPATIAL.webMap.PORTALURL + "/" + webMapID + "/data";
					}

					var thisObj = this;
					var preCallBack = function ( ioArgs ) {
						console.debug( "get Token Value From Web Map Credentials: " + ioArgs.url,
								ioArgs.content );
						var tokenValue = "";
						
						//Get the webmap item URL domain
						var urlSchemeEndString = "://";
						var itemURLSchemeEnd = arcgisUtils.arcgisUrl.indexOf(urlSchemeEndString);
						var itemDomainIndex = (itemURLSchemeEnd > -1) ?  itemURLSchemeEnd + urlSchemeEndString.length : 0;
						var itemURLDomain = arcgisUtils.arcgisUrl.substr(itemDomainIndex);
						
						//Check if the URL is for the Web Map item
						var isURLForWebMap = (ioArgs.url.indexOf(itemURLDomain) > -1) ;

						if (isURLForWebMap) {
							tokenValue = thisObj.validateUrlToken
							.getTokenValueForWebCreate(ioArgs.url);
						} else {
							if (thisObj.validateUrlToken.checkIfTokenNeeded(ioArgs.url)) {
								tokenValue = thisObj.validateUrlToken
								.getTokenInfo(null, ioArgs.url);
							}
						}
						
						if ( tokenValue != "" ) {
							if ( ioArgs.content == null ) {
								ioArgs.content = {};
							}
							ioArgs.content.token = tokenValue;
						}
						return ioArgs;
					}

					esriRequest.setRequestPreCallback( preCallBack );

					arcgisUtils
							.createMap( webMapID, dojo.create( "div" ), createMapOptions )
							.then(
									lang
											.hitch(
													this,
													function ( response ) {
														console.log( "[Web Map Title] Title: ",
																response.itemInfo.item.title );
														// get the mbo position
														console.log( "[Web Map Title] Title: ",
																response.itemInfo.item.title );
														// Create the map only when we have a center
														// defined
														var webMapCenter = new dojo.Deferred();

														response.itemInfo.itemData.baseMap.baseMapLayers.forEach(this.makeWebMapLayerPortable);
														response.itemInfo.itemData.operationalLayers.forEach(this.makeWebMapLayerPortable);

														esriRequest.setRequestPreCallback( null );
														if ( this.mapConf.SPATIAL.openStreetMap
																|| this.mapConf.SPATIAL.bingMaps ) {
															var firstLayerSpatialReference = new SpatialReference(
																	{
																		"wkid" : 102100
																	} );
														} else if ( response.itemInfo.itemData.baseMap
																|| !( options.spatial.mapservices[ 0 ] ) ) {
															var firstLayerSpatialReference = new SpatialReference(
																	response.itemInfo.itemData.spatialReference );
														} else {
															var firstLayerSpatialReference = this
																	.findLayerSpatialReference( options.spatial.mapservices[ 0 ].url );
														}
														
														if (!this.mapConf.isInMapManager) { 
															when(firstLayerSpatialReference, dojo.hitch(this,function (firstSpatialReference ) {
																				this.firstLayerSpatialReference = firstSpatialReference;
																				this._getMapInitialPosition().then(
																						dojo.hitch(this,function (center ) {
																									mapMboCenterPromise
																									.resolve( center );
																				} ) );
															} ) );
														}
														
														deferredMapCenter
																.then( lang
																		.hitch(
																				this,
																				function () {
																					this.map = new this.createEsriMap(
																						this,
																						element.id,
																						mapOpts
																					);
																					this.setMapLoadingImage(element.id);
																					this.showLoadingImg();
																					this.map.webMapResponse = response;
																					this
																							._initAfterMapCreation(
																									this,
																									element,
																									options,
																									this.extentInitiallySet,
																									mapInitialExtent );
																					def.callback( this );
																				} ) );
													} ),
									function ( error ) {
										var errorJson = dojo.toJson( error );
										console.error( 'Creation of Web Map Failed: ', errorJson );
										def.resolve( me );
										me.getMaximo().showMessage( "mapcontrol",
												"doNotHavePermissions", [
													error.message
												] );
									} );
				} else {
					console.log( "[Create Normal Map Started]" );

					// Create the map only when we have a center defined
					deferredMapCenter.then( lang.hitch( this, function () {
						this.map = this.createEsriMap( this, element.id, mapOpts );
						this.setMapLoadingImage(element.id);
						this.showLoadingImg();
						this._initAfterMapCreation( this, element, options, this.extentInitiallySet,
								mapInitialExtent );
						def.resolve(me);
					} ) );
				}

			} catch ( e ) {
				this.hideLoadingImg();
				console.error( "ERROR in the map creation: " + e );
				if ( this.messageDiv ) {
					this
							.writeMessageInBox( this.messageDiv, "plussmap", "mapCreationError", null,
									true );
					if ( domClass.contains( this.messageDiv, "messageDivNotVisible" ) ) {
						throw e;
					}
				} else {
					throw e;
				}
			}
			return def.promise;
		},

		createEsriMap: function ( me, id, mapOptions ) {
			var map = new Map( id, mapOptions );

			me.overrideEsriMapMethods( me, map );

			return map;
		},

		// Override Esri Map addLayer and addLayers methods in order to configure layers
		// visibility accordingly to toolsJson object. 
		overrideEsriMapMethods: function ( me, map ) {
			function fixLayerVisibility( layer ) {
				var persistedVisibility = me.getLayerPersistedVisibility( layer );
				if ( persistedVisibility !== null ) {
					layer.setVisibility( persistedVisibility );
				}

				if ( layer instanceof ArcGISDynamicMapServiceLayer ) {
					var visibleLayers = me.getLayerPersistedVisibleLayers( layer );
					if ( visibleLayers !== null ) {
						layer.setVisibleLayers( visibleLayers );
					}
				}
			}

			var addLayer = dojo.hitch( map, map.addLayer );
			function customAddLayer( layer, index ) {
				fixLayerVisibility( layer );
				addLayer( layer, index );
			}
			map.addLayer = customAddLayer;

			var addLayers = dojo.hitch( map, map.addLayers );
			function customAddLayers( layers ) {
				dojo.forEach( layers, fixLayerVisibility );
				addLayers( layers );
			}
			map.addLayers = customAddLayers;
		},

		makeWebMapLayerPortable: function ( esriWebMapLayer ) {

			var layerType = esriWebMapLayer.layerType || esriWebMapLayer.type;

			if ( !esriWebMapLayer.type ) {
				esriWebMapLayer.type = layerType;
			} 

		},

		setMapOptsInitialPosition : function ( center, lastExtent, options, mapOpts ) {
			var returnDeferred = false;
			if ( center ) {
				if ( !center.spatialReference ) {
					if ( center.sr ) {
						center = new Point( center.lng, center.lat, new SpatialReference( center.sr ) );
					} else {
						this.centerWithNoSpatialReference = true;
					}
				}
				// If a center point is returned (1 mbo only)
				if ( center.type === "point" ) {
					mapOpts.center = center;

					// Get layer info to determine the correct zoom level
					var mboInfo = this.currentRecordMgr.mboInfo
					var layerInfoData = this._getLayerMappingForMbo( mboInfo );
					if ( this.mapConf.autoZoomToFeature == "1" && layerInfoData
							&& layerInfoData.length > 0 ) {
						var layerInfoDeferred = new dojo.Deferred();
						var layerURL = layerInfoData[ 0 ].url;
						layerURL = this.validateUrlToken.addTokenIfApplicable( layerURL );
						var requestPromise = this.getLayerInfo( layerURL );
						returnDeferred = true;
						requestPromise.then( lang.hitch( this, function ( layerDetails ) {
							var optimizedScale = this.getOptimizedScaleFromLayer( layerDetails, 2256.9943525 );
							var optimizedLOD = this.getOptimizedLevelOfDetailFromLayer(optimizedScale);
							if (optimizedLOD) {
								mapOpts.zoom = optimizedLOD;
							} else {
								mapOpts.scale = optimizedScale;
							}
							this.extentInitiallySet = true;
							layerInfoDeferred.resolve();
						} ) )
					} else {
						if ( ( this.hasLastUserLocation ) && ( options.lastUserLocationData.level ) ) {
							mapOpts.zoom = options.lastUserLocationData.level;
						} else if ( ( this.toolsJson ) && ( this.toolsJson.zoomLevel ) ) {
							mapOpts.zoom = this.toolsJson.zoomLevel;
						} else if ( this.mapConf.initialLocation ) {
							mapOpts.zoom = this.mapConf.initialLocation.level;
						} else {
							mapOpts.zoom = this.DEFAULT_INITIAL_ZOOM;
						}
						this.extentInitiallySet = true;
					}
					// if an extent is returned (more then one mbo)
				} else if ( center.type === "extent" ) {
					mapOpts.extent = center;
					this.extentInitiallySet = true;
				}
			} else {
				if (  !this.mapConf.initialLocation && lastExtent ) {
					mapOpts.extent = lastExtent;
					mapOpts.level = lastExtent.level;
					this.extentInitiallySet = true;
				}
			}
			if ( returnDeferred ) {
				return layerInfoDeferred.promise;
			} else {
				return 0;
			}

		},
		findLayerSpatialReference : function ( layerURL ) {
			var firstlayerDeferred = new dojo.Deferred();
			var tileInfoSpatialReference = null;
			layerURL = this.validateUrlToken.addTokenIfApplicable( layerURL );
			var requestPromise = this.getLayerInfo( layerURL );
			requestPromise.then( dojo.hitch( this, function ( layerDetails ) {
				if (layerDetails.tileInfo) {
					this.firstLayerTileInfo = layerDetails.tileInfo;
					tileInfoSpatialReference = layerDetails.tileInfo.spatialReference;
				}
				var firstLayerSpatialReference = new SpatialReference( layerDetails.spatialReference || tileInfoSpatialReference );
				firstlayerDeferred.resolve( firstLayerSpatialReference );
			}), dojo.hitch(function(error) {
				if ( this.messageDiv ) {
					this.writeMessageInBox( this.messageDiv, "plussmap", "layerRequestError", [layerURL, error.message], true );
				}
				console.error(error);
			} ) );
			return firstlayerDeferred.promise;
		},
		createMessageBox : function () {
			var existedCopyMessageButton = dijit.byId( "copyMessageButton" );
			if ( existedCopyMessageButton ) {
				existedCopyMessageButton.destroyRecursive( true );
			}
			this.copyMessageButton = new Button(
					{
						id : "copyMessageButton",
						label : i18n.getMaxMsg( "plussmap", "copyMessagesToClipboard" ),
						showLabel : false,
						"class" : "copyPasteMessageButton",
						iconClass : "copyPasteMessageIconButton spatialToolPaneIcon",
						onClick : dojo
								.hitch(
										this,
										function () {
											var selectionRange = null;
											var selection = window.getSelection();
											// if there are ranges selected, check if the selection
											// starts in the Messages Box
											if ( ( selection.rangeCount > 0 )
													&& ( selection.getRangeAt( 0 ).startContainer == this.messageDiv ) ) {
												var selectionRange = selection.getRangeAt( 0 );
											}
											// If the messages are already selected, clean the selection
											if ( selectionRange
													&& ( selectionRange.startOffset != selectionRange.endOffset ) ) {
												selection.removeAllRanges();
												// If the messages are not selected, select and copy
												// them
											} else {
												selection.removeAllRanges();
												var range = document.createRange();
												range.selectNodeContents( this.messageDiv );
												selection.addRange( range );
												document.execCommand( "copy" );
											}
										} )
					} );
			var existedCollapseExpandButton = dijit.byId( "collapseExpandButton" );
			if ( existedCollapseExpandButton ) {
				existedCollapseExpandButton.destroyRecursive( true );
			}
			this.collapseExpandButton = new Button( {
				id : "collapseExpandButton",
				label : i18n.getMaxMsg( "plussmap", "collapse" ),
				showLabel : false,
				"class" : "collapseExpandButton collapseButton",
				iconClass : "collapseMessageBoxButton spatialToolPaneIcon",
				onClick : dojo.hitch( this, function () {
					dojo.toggleClass( this.messageDiv, "messageDivNotVisible" );

					dojo.toggleClass( this.copyMessageButton.domNode, "messageDivNotVisible" );

					dojo.toggleClass( this.collapseExpandButton.iconNode, "expandMessageBoxButton" );
					dojo.toggleClass( this.collapseExpandButton.iconNode, "collapseMessageBoxButton" );

					dojo.toggleClass( this.collapseExpandButton.domNode, "collapseButton" );
					dojo.toggleClass( this.collapseExpandButton.domNode, "expandButton" );

					if ( domClass
							.contains( this.collapseExpandButton.domNode, "expandMessageBoxButton" ) ) {
						this.collapseExpandButton.label = i18n.getMaxMsg( "plussmap",
								"expand" );
					} else {
						this.collapseExpandButton.label = i18n.getMaxMsg( "plussmap",
								"collapse" );
					}
				} )
			} );
			this.messageDiv = domConstruct.create( "div", {
				"class" : "mapMessages"
			} );
			domConstruct.place( this.copyMessageButton.domNode, this.element, "last" );
			domConstruct.place( this.collapseExpandButton.domNode, this.element, "last" );
			domConstruct.place( this.messageDiv, this.element, "last" );
		},
		/**
		 * Calculate the optimized Scale for a particular layer considering the Min Scale, Max Scale and
		 * Effective Min Scale.
		 */
		getOptimizedScaleFromLayer : function ( layerJsonDetails, currentScale ) {
			var newScale = null;
			var scaleMeetsRange = false;
			var minScale = layerJsonDetails.minScale;
			var maxScale = layerJsonDetails.maxScale;

			if ( minScale == 0 && maxScale == 0 ) {
				scaleMeetsRange = true;
			} else if ( minScale != 0 && maxScale == 0 ) {
				if ( currentScale != null && currentScale <= minScale )
					scaleMeetsRange = true;
			} else if ( minScale == 0 && maxScale != 0 ) {
				if ( currentScale != null && currentScale >= maxScale )
					scaleMeetsRange = true;
			} else {
				if ( currentScale != null && currentScale <= minScale && currentScale >= maxScale )
					scaleMeetsRange = true;
			}

			if ( scaleMeetsRange == true ) {
				newScale = currentScale;
			} else {
				if ( layerJsonDetails.effectiveMinScale == null
						|| layerJsonDetails.effectiveMinScale == undefined ) {
					newScale = ( maxScale + minScale ) / 2;
				} else {
					newScale = layerJsonDetails.effectiveMinScale;
				}
			}
			return newScale;
		},
		getOptimizedLevelOfDetailFromLayer: function(scale) {
			var levelOfDetail;
			if (this.firstLayerTileInfo && this.firstLayerTileInfo.lods) {
				dojo.forEach(this.firstLayerTileInfo.lods, function(level) {
					if ((level.scale < scale) && !levelOfDetail) {
						levelOfDetail = level.level ;
					}
				}, this);
				
			}
			return levelOfDetail;
		},

		_resizeInfoWindow: function ( width = 300, height = 400 ) {
			var MIN_HEIGHT = 200;
			var MIN_WIDTH = this.mapConf.minWidthIdentifyDialog || 200;

			width = Math.max(width, MIN_WIDTH);
			height = Math.max(height, MIN_HEIGHT);

			var widthPx = `${width}px`;
			var heightPx = `${height}px`;

			var divResizable = dojo.byId( 'divIndoWindowResizable' );
			dojo.style( divResizable, {
				height: heightPx,
				width: widthPx,
			});

			var esriPopupWrapper = this.map.infoWindow.domNode.childNodes[ 0 ];
			dojo.style( esriPopupWrapper, {
				height: heightPx,
				width: widthPx,
			});

			esriPopupWrapper.childNodes.forEach( function ( child ) {
				var classes = child.className.split(' ');

				if ( !classes.includes( "sizer" ) )
					return;

				if ( classes.includes( "pointer" ) )
					return;

				dojo.style( child, { width: widthPx });
			});

			var contentHeight = divResizable.offsetHeight;
			var content = null;
			esriPopupWrapper.childNodes.forEach( function ( child ) {
				var classes = child.className.split(' ');

				if ( !classes.includes( "sizer" ) )
					return;

				if ( classes.includes( "content" ) ) {
					content = child;
					return;
				}

				contentHeight -= child.offsetHeight;
			});

			if ( content ) {
				var contentPane = content.childNodes[ 0 ];
				dojo.style( contentPane, {
					maxHeight: `${contentHeight}px`,
				});
				
				var popupView = query( '.esriViewPopup', contentPane )[ 0 ];
				var hasNoContent = !popupView;
				dojo.style( content, {
					position: 'relative',
					height: `${contentHeight}px`,
					borderBottom: hasNoContent ? 'none' : '1px solid lightgrey',
				} );
			}
		},

		_subscribeToInfoWindowEvents: function () {
			var infoWindow = this.map.infoWindow;

			this.infoWindowShowListener = dojo.connect( infoWindow, "onShow", dojo.hitch( this, this._infoWindowShowed ) );
			this.infoWindowClickListener = on( infoWindow.domNode, "pointerdown, mousedown", dojo.hitch( this, this._infoWindowFocused ) );
			this.infoWindowMaximizeListener = dojo.connect( infoWindow, "onMaximize", dojo.hitch( this, this._infoWindowResized ) );
			this.infoWindowRestoreListener = dojo.connect( infoWindow, "onRestore", dojo.hitch( this, this._infoWindowResized ) );
			this.infoWindowSetContentListener = dojo.connect( infoWindow, "setContent", dojo.hitch( this, this._infoWindowResized ) );
			this._makeInfoWindowMovable();
			this._makeInfoWindowResizable();
		},

		_makeInfoWindowMovable: function () {
			var infoWindow = this.map.infoWindow;
			var infoWindowTitle = query( ".titlePane", infoWindow.domNode );

			this.infoWindowMovableHandle = new Moveable( infoWindow.domNode, {
				handle: infoWindowTitle,
			} );
			this.infoWindowMovableTooltip = new Tooltip( {
				id: "tooltipMoveable",
				connectId: infoWindowTitle,
				label: i18n.getMaxMsg( "plussmap", "flyoverMoveableDialog" ),
				showDelay : this.showDelayTimeTooltip,
			} );
			this.infoWindowMoveStartListener = dojo.connect( this.infoWindowMovableHandle, "onMoveStart", dojo.hitch( this, this._infoWindowFocused ) );
		},

		_makeInfoWindowResizable: function () {
			var divResizable = dojo.create( 'div', {
				id: "divIndoWindowResizable",
				"class": "divIndoWindowResizable"
			} );
			var esriPopupWrapper = this.map.infoWindow.domNode.childNodes[ 0 ];
			dojo.place( divResizable, esriPopupWrapper, "first" );

			var handle = dojo.create( 'div' );
			dojo.place( handle, divResizable, "last" );
			
			this.infoWindowResizableHandle = new ResizeHandle( {
				targetId: "divIndoWindowResizable",
				activeResize: true,
				intermediateChanges: true,
				animateMethod: "combine",
				minWidth: 1,
				minHeight: 1
			}, handle );
			this.infoWindowResizableHandle.startup();

			this.infoWindowResizableTooltip = new Tooltip( {
				id: "tooltipResize",
				connectId: this.infoWindowResizableHandle.domNode,
				label: i18n.getMaxMsg( "plussmap", "flyoverResizeDialog" ),
				showDelay: this.showDelayTimeTooltip
			} );
			this.infoWindowResizeListener = dojo.connect( this.infoWindowResizableHandle, "onResize", dojo.hitch( this, function () {
				var height = divResizable.offsetHeight;
				var width = divResizable.offsetWidth;

				this._resizeInfoWindow( width, height );
			} ) );

			// Fix anchor in bottom right position to avoid mispositioning the location pointer during resize
			this.map.infoWindow.set("anchor", "bottom-right");
		},

		_infoWindowShowed: function () {
			var esriPopupWrapper = this.map.infoWindow.domNode.childNodes[ 0 ];
			this._resizeInfoWindow( esriPopupWrapper.offsetWidth, esriPopupWrapper.offsetHeight );

			this._infoWindowFocused();
		},

		_infoWindowFocused: function () {
			dojo.publish( "infoWindowFocused", this.map.infoWindow.domNode );
		},

		_infoWindowResized: function () {
			var contentPane = this.map.infoWindow._contentPane;
			var width = contentPane.offsetWidth;
			var height = contentPane.offsetHeight;

			this._resizeInfoWindow( width, height );
		},

		destroyInfoWindow: function () {
			var listeners = [ 
				this.infoWindowShowListener, 
				this.infoWindowClickListener, 
				this.infoWindowMoveStartListener,
				this.infoWindowResizeListener,
				this.infoWindowMaximizeListener,
				this.infoWindowRestoreListener,
				this.infoWindowSetContentListener,
			];
			for ( var listener of listeners ) {
				if ( !listener ) {
					continue;
				}

				if ( dojo.isArray( listener ) ) {
					for ( var subListener of listener ) {
						subListener.remove();
					}
				} else {
					listener.remove();
				}
			}

			var handlers = [
				this.infoWindowMovableHandle,
				this.infoWindowResizableHandle,
			];
			for ( var handler of handlers ) {
				if ( handler ) {
					handler.destroy();
				}
			}

			var tooltips = [
				this.infoWindowMovableTooltip,
				this.infoWindowResizableTooltip,
			];
			for ( var tooltip of tooltips ) {
				if ( tooltip ) {
					tooltip.destroyRecursive( true );
				}
			}

			if ( this.map.infoWindow ) {
				this.map.infoWindow.destroy();
			}
		},

		_initAfterMapCreation : function ( me, element, options, extentInitiallySet, mapInitialExtent ) {

			this._subscribeToInfoWindowEvents();
			me.mapDivId = element.id;
			// adjust pan rate and duration to provide a better
			// user experience
			// during drag and drop of the marker
			esriConfig.defaults.map.panDuration = 500; // time
			// in
			// milliseconds;
			// default
			// panDuration:250
			esriConfig.defaults.map.panRate = 15; // refresh
			// rate of
			// zoom
			// animation;
			// default
			// panRate:25

			// var map = me.map;

			me.map.extentInitiallySet = extentInitiallySet;
			var defLenUnit = 'metric';
			if ( options.defaultLenUnit == "MILES" ) {
				defLenUnit = 'english';
			}
			var spatialNavigation = new Navigation( me.map );
			var spatialMapManager = new MaximoSpatialMxn( {
				map : me.map,
				mapConfig : me.mapConf,
				mapstraction : me,
				mapNavigation : spatialNavigation,
				mapInitialExtent : mapInitialExtent,
				lenUnit : defLenUnit,
				esriGeometryService : me.esriGeometryService,
				messageDiv : this.messageDiv
			} );
			spatialMapManager.loadMap( options.spatial );
			me.map.spatialMapManager = spatialMapManager;

			me.toWebMercatorCache = {};
			/* function to convert lat/lng to maximo spatial reference */
			/* Note: this is a GLOBAL function */
			projectPointsToWebMercator = function ( points, callbackFct, errCallback ) {
				return spatialMapManager.projectPointsToWebMercator( points, callbackFct, errCallback );
			};
			me.fromWebMercatorCache = {};
			/* function to convert x/y in maximo spatial reference to lat/lng */
			/* Note: this is a GLOBAL function */
			projectPointsFromWebMercator = function ( points, callbackFct, errCallback ) {
				return spatialMapManager
						.projectPointsFromWebMercator( points, callbackFct, errCallback );
			};
			dojo.connect( me.map, "onClick", function ( evt ) {
				me.fireMapEvent( me.Events.click, [
					{
						'location' : me.latLng( evt.mapPoint.y, evt.mapPoint.x ),
						'pixel' : evt.screenPoint,
						'point' : evt.mapPoint
					}
				] );
				me.map.infoWindow.hide();
			} );

			dojo.connect( dojo.byId( element.id ), "oncontextmenu", function ( evt ) {
				me.stopEventPropagation( evt );
				dojo.stopEvent( evt );
			} );

			dojo.connect( dojo.byId( element.id ), "contextmenu",
					dojo.hitch(this, function ( evt ) {
						me.stopEventPropagation( evt );
						dojo.stopEvent( evt );
						var fct = function ( e ) {
							var posx = 0;
							var posy = 0;
							if ( !e )
								var e = window.event;
							if ( e.pageX || e.pageY ) {
								posx = e.pageX;
								posy = e.pageY;
							} else if ( e.clientX || e.clientY ) {
								posx = e.clientX + document.body.scrollLeft
										+ document.documentElement.scrollLeft;
								posy = e.clientY + document.body.scrollTop
										+ document.documentElement.scrollTop;
							}

							return {
								x : posx,
								y : posy
							};
						};

						var x = fct( evt ).x;
						var y = fct( evt ).y;
						y -= dojo.coords( dojo.byId( me.mapDivId ) ).y;
						x -= dojo.coords( dojo.byId( me.mapDivId ) ).x;

						var pt = new esri.geometry.Point( x, y );
						

						var latLng = me.map.toMap( pt );

						var fireEventFunction = function(latLng, pixelX, pixelY) {
							var point = me.latLng( latLng.y, latLng.x );
	
							me.fireMapEvent( me.Events.rightclick, [
								{
									'location' : point,
									'pixel' : {
										x : pixelX,
										y : pixelY
									}
								}
							] );
						};
						//Initially normalization will be for web mercator only. Later we can try to apply to geographic coordinates.
						if ( this.esriGeometryService && me.map.spatialReference.isWebMercator()) {
							NormalizeUtils.normalizeCentralMeridian([latLng],this.esriGeometryService, dojo.hitch(this, function(points) {
								fireEventFunction(points[0], x, y);
							}), dojo.hitch(this, function(error) {
								console.error("Point normalization failed. ");
								fireEventFunction(latLng, x, y)
							}))
						} else {
							console.warn("The point will not be normalized");
							fireEventFunction(latLng, x, y)
						}

						return true;
					} ));

			if ( this.mapConf.isPreviewMobile ) {
				// Draw the region for Preview Mobile
				var isPreviewMobileMapHandle = dojo.subscribe( "mxmap.mapLoaded", dojo.hitch( this,
						function ( eventMap ) {
							dojo.unsubscribe( isPreviewMobileMapHandle );
							var map = eventMap.map;
							var extent = eventMap.mapConf.initialLocation.extent;
							var polygonJsonExtent = {
								"rings" : extent,
								"spatialReference" : eventMap.map.spatialReference
							};
							var initialExtent = new Polygon( polygonJsonExtent );
							var lat = eventMap.mapConf.initialLocation.lat;
							var lng = eventMap.mapConf.initialLocation.lng;

							map.on( 'extent-change', function ( event ) {
								var currentCenter = map.extent.getCenter();
								var currentZoom = map.getZoom();
								if ( initialExtent && !initialExtent.contains( currentCenter )
										&& event.delta && event.delta.x !== 0 && event.delta.y !== 0 ) {
									var newCenter = map.extent.getCenter();
									var centralize = false;
									map.centerAt( initialExtent.getExtent().getCenter() );
								}
							} );

							var sfs = new SimpleFillSymbol( esri.symbol.SimpleFillSymbol.STYLE_SOLID,
									new SimpleLineSymbol( esri.symbol.SimpleLineSymbol.STYLE_DASHDOT,
											new Color( [
													255, 0, 0
											] ), 2 ), new Color( [
											255, 255, 0, 0.0
									] ) );

							var graphic = new Graphic( initialExtent, sfs );
							var previewLayer;
							if ( eventMap.map.getLayer( "previewLayer" ) === undefined ) {
								previewLayer = new esri.layers.GraphicsLayer( {
									id : "previewLayer"
								} );
								eventMap.map.addLayer( previewLayer );
							} else {
								previewLayer = eventMap.map.getLayer( "previewLayer" );
							}
							console.log( eventMap.map.graphicsLayerIds );

							previewLayer.add( graphic );

						} ) );
			}

			this.onMaximoMapLoaded = dojo.subscribe( 
				"mxmap.mapLoaded", 
				dojo.hitch( this, function ( event ) {
					dojo.unsubscribe( this.onMaximoMapLoaded );

					var map = event.map;
					this.loadMapLegends( map );
				} ) 
			);
		},

		/**
		 * destroys map implementation
		 */
		destroyMap : function () {
			this.destroyMapLegends();
			this.destroyInfoWindow();

			if ( this.onMaximoMapLoaded ) {
				dojo.unsubscribe( this.onMaximoMapLoaded );
			}
			if ( this.refreshMapHandle ) {
				dojo.disconnect( this.refreshMapHandle );
			}
			if ( this._connections ) {
				for ( var link in this._connections ) {
					dojo.disconnect( this._connections[ link ] );
				}
			}
			// destroy all DIJITs registered by Esri api:
			try {
				var mapDiv = dojo.byId( this.mapDivId );
				var esriWidgets = dijit.findWidgets( mapDiv );

				dojo.forEach( esriWidgets, function ( w ) {
					var id = w.id;
					if ( id.indexOf( "esri" ) > -1 ) {
						w.destroyRecursive( true );
					}
				} );
			/*rollback the Mapping to EsriDojo
			 *Without it the Maximo widgets will not work properly in other pages
			 */
			document.__dojoToDomId = ibm.tivoli.fwm.mxmap.factory._dojoToDomId;
			require({map: {"*": {dojo: "dojo", dijit: "dijit", dojox: "dojox"}}}, ["require"]);
			} catch ( e ) {
				console.warn( "exception destroying map", e );
			}
		},

		getMapType : function () {
		},
		setMapType : function ( type ) {
		},

		getCenter : function () {
			var map = this.getProviderMap();
			var pt = map.extent.getCenter();
			return this.latLng( pt.y, pt.x );
		},
		setCenter : function ( point, options ) {
			var map = this.getProviderMap();
			var pt = point.toProprietary();
			if ( map.spatialMapManager.isPointInFullExtent( pt ) == false ) {
				return;
			}
			me = this;
			if ( me.map.targetCenter != null ) {
				
				setTimeout(function() {
					pt = me.map.targetCenter;
					map.centerAt( pt );
					if ( me.state && me.state.updating != true ){
						me.map.targetCenter = null;
					}
				}, 500);
				
			} else {
				map.centerAt( pt );
			}
		},

		getZoom : function () {
			var map = this.getProviderMap();
			// var zoom = map.getLevel();
			if ( map.getLevel() == -1 ) {
				if ( map._maximo && map._maximo.mapStartingWidth ) {
					return ( map.extent.getWidth() / map._maximo.mapStartingWidth );
				} else {
					// no way to know the current level
					return 1;
				}
			} else {
				return map.getLevel();
			}
		},
		setZoom : function ( zoom ) {
			var map = this.getProviderMap();

			map.centerAndZoom( map.extent.getCenter(), zoom );
		},

		setCenterAndZoom : function ( point, zoom ) {
			var map = this.getProviderMap();

			var pt = point.toProprietary();

			if ( map.spatialMapManager.isPointInFullExtent( pt ) == false ) {
				console.warn( "[Maximo Spatial] Map extent does not contain center point to zoom",
						point );
			}

			// Adding this timer because we need to wait some time after the map loads
			// to use centerAt and centerAndZoom APIs, otherwise they won't work properly.
			var me = this;
			
			setTimeout(function() {
				if ( me.map.targetCenter != null ) {
					pt = me.map.targetCenter;
					map.centerAt( pt );
					if ( me.state && me.state.updating != true ) {
						me.map.targetCenter = null;
					}
				}
				if ( zoom ) {
					map.centerAndZoom( pt, zoom );
				} else {
					map.centerAt( pt );
				}
			}, 500);

		},
		zoomToServerInitialExtent : function () {
			var layer = this.map.getLayer( this.map.layerIds[ 0 ] );
			var initialExtent = layer.initialExtent;
			var spatialReference = new SpatialReference( layer.spatialReference );
			var extent = new Extent( initialExtent.xmin, initialExtent.ymin, initialExtent.xmax,
					initialExtent.ymax, spatialReference )
			this.map.setExtent( extent );
		},
		setExtentLatLng : function ( latitude, longitude, level ) {
			var spatialReference = this.map.spatialReference;
			var extCenterPoint = new Point( longitude, latitude, spatialReference );
			this.map.centerAndZoom( extCenterPoint, level );
		},
		getBoundingBox : function ( swLat, swLng, neLat, neLng ) {
			return new MaximoSpatialBoundingBox( swLat, swLng,
					neLat, neLng );
		},
		getBounds : function () {
			var map = this.getProviderMap();
			var bounds = map.extent;
			return this.getBoundingBox( bounds.ymin, bounds.xmin, bounds.ymax, bounds.xmax );
		},
		setBounds : function ( bounds ) {
			var map = this.getProviderMap();
			var sw = bounds.sw;
			var ne = bounds.ne;
			var bnd = new esri.geometry.Extent( parseFloat( sw.lon ), parseFloat( sw.lat ),
					parseFloat( ne.lon ), parseFloat( ne.lat ), map.spatialReference );
			map.setExtent( bnd, true );
		},

		/*
		 * Always in WGS84
		 */
		getAllPointsFromWGS84 : function ( points, callback, errCb ) {
			if ( window.mx.esri.sr && window.mx.esri.sr.wkid ==this. WGS84WKID ) {
				callback( points );
			} else {
				var map = this.getProviderMap();
				var fct = function ( points ) {

					callback( points );
				};
				if ( errCb == null ) {
					errCb = function ( errorMsgInfo ) {
						this.maximo.showMessage( errorMsgInfo.msggroup, errorMsgInfo.msgkey );
						console.log( errorMsgInfo );
					}
				}
				projectPointsFromWebMercator( points, dojo.hitch( this, fct ), errCb );
			}
		},
		getAllPointsInWGS84 : function ( points, callback, errCb ) {
			if ( window.mx.esri.sr && window.mx.esri.sr.wkid == this.WGS84WKID ) {
				callback( points );
			} else {
				var map = this.getProviderMap();
				var fct = function ( points ) {
					callback( points );
				};
				if ( errCb == null ) {
					errCb = function ( errorMsgInfo ) {
						this.maximo.showMessage( errorMsgInfo.msggroup, errorMsgInfo.msgkey );
						console.log( errorMsgInfo );
					}
				}
				projectPointsToWebMercator( points, dojo.hitch( this, fct ), dojo.hitch( this, errCb ) );
			}
		},

		resizeTo : function ( width, height, ww, hh ) {
			var map = this.getProviderMap();
			dojo.style( dojo.byId( this.mapDivId ), "width", width );
			// Issue 12-13085
			// Issue 12-13543: Need to convert to string before attempting to use indexOf
			var strWidth = width.toString();
			if ( strWidth.indexOf( "%" ) > -1 ) {
				strWidth = "100%";
			}
			dojo.style( map.root, "width", strWidth );
			hh = hh | height;
			dojo.style( dojo.byId( this.mapDivId ), "height", hh );

			// In order to resize, the spatialReference must be known beforehand
			// Thefore, just resize if spatialReference was set
			if ( map.spatialReference ) {
				map.resize();
				map.reposition();
			}
		},
		clearMarkerLayer : function () {
			var providerMarkerLayer = this.map.getLayer( "providerMarkerLayer" );
			if ( providerMarkerLayer ) {
				providerMarkerLayer.clear();
			}
		},
		createProviderMarker : function ( point, markerData ) {
			var map = this.getProviderMap();

			var params = {
				point : point,
				map : this,
				compId : this.compId,
				isMobile : this.isMobile
			};
			dojo.mixin( params, markerData );
			var marker = new MaximoSpatialMarker( params );
			if ( marker && markerData ) {
				marker.addData( markerData );
			}
			var pin = marker.toProprietary();
			marker.setChild( pin );

			var providerMarkerLayer;
			if ( map.getLayer( "providerMarkerLayer" ) === undefined ) {
				providerMarkerLayer = new esri.layers.GraphicsLayer( {
					id : "providerMarkerLayer"
				} );
				map.addLayer( providerMarkerLayer );
			} else {
				providerMarkerLayer = map.getLayer( "providerMarkerLayer" );
			}
			var gPin = providerMarkerLayer.add( pin );
			if ( marker.proprietary_marker_label ) {

				providerMarkerLayer.add( marker.proprietary_marker_label );
			}

			return marker;
		},
		removeMboHighligh : function ( mboInfo ) {
			if ( !mboInfo || !mboInfo.mxdata || !mboInfo.mxdata.uid ) {
				console.warn("invalid mboInfo", mboInfo);

				return;
			}

			var uid = mboInfo.mxdata.uid;
			
			if ( 
				uid.name === undefined || 
				uid.name === null || 
				uid.value === undefined || 
				uid.value === null
			) {
				console.warn("invalid mboInfo.mxdata.uid", uid);

				return;
			}
			
			var providerHighlightLayer = this.map.getLayer( "providerHighlightLayer" );

			if ( !providerHighlightLayer || !providerHighlightLayer.graphics ) {
				console.warn("invalid providerHighlightLayer", providerHighlightLayer);

				return;
			}

			var mboInfoGraphic = providerHighlightLayer.graphics.find( function ( graphic ) {
				var attributes = graphic.attributes || {};

				return attributes.name === uid.name && attributes.value === uid.value;
			} );

			if ( mboInfoGraphic ) {
				providerHighlightLayer.remove( mboInfoGraphic );
			}
		},
		removeProviderMarker : function ( marker ) {
			var map = this.getProviderMap();

			var providerMarkerLayer = this.map.getLayer( "providerMarkerLayer" );
			if ( providerMarkerLayer ) {
				providerMarkerLayer.remove( marker.proprietary_marker );
			}

			// map.graphics.remove( marker.proprietary_marker );
			if ( marker.proprietary_marker_label && providerMarkerLayer ) {
				providerMarkerLayer.remove( marker.proprietary_marker_label );
			}
			marker.closeBubble();
		},

		polyline : function ( params ) {
			return new MaximoSpatialPolyline( params );
		},

		createProviderPolyline : function ( polyline, polylineData ) {
			var map = this.getProviderMap();

			var providerPolylineLayer;
			if ( this.map.getLayer( "providerPolylineLayer" ) === undefined ) {
				providerPolylineLayer = new esri.layers.GraphicsLayer( {
					id : "providerPolylineLayer"
				} );
				this.map.addLayer( providerPolylineLayer );
			} else {
				providerPolylineLayer = this.map.getLayer( "providerPolylineLayer" );
			}
			this.moveMarkerLayerToTop();
			var colorTemp = new dojo.Color( polyline.color );
			var color = new dojo.Color( [
					colorTemp.r, colorTemp.g, colorTemp.b, polyline.opacity
			] );

			var centerPoint = polyline.getAttribute( "centerPoint" );
			var radiusInKMs = polyline.getAttribute( "radiusInKMs" );
			if ( centerPoint && radiusInKMs ) {
				var params = new esri.tasks.BufferParameters();
				var pt = centerPoint.toProprietary();
				params.geometries = [
					pt
				];
				params.distances = [
					radiusInKMs
				];
				params.unit = esri.tasks.GeometryService.UNIT_KILOMETER;
				params.bufferSpatialReference = map.spatialReference;
				params.outSpatialReference = map.spatialReference;

				var onComplete = function ( geometries ) {
					var _fillColor = new dojo.Color( polyline.fillColor || "#000000" );
					_fillColor.a = ( polyline.opacity || 1.0 ) / 2.0;
					var symbol = new esri.symbol.SimpleFillSymbol(
							esri.symbol.SimpleFillSymbol.STYLE_SOLID, new esri.symbol.SimpleLineSymbol(
									esri.symbol.SimpleLineSymbol.STYLE_SOLID, color, 3 ), _fillColor );
					var graphic = new esri.Graphic( geometries[ 0 ], symbol );
					/* removes the temporary graphic */
					if ( polyline.esri_graphic ) {
						providerPolylineLayer.remove( polyline.esri_graphic );
					}
					providerPolylineLayer.add( graphic );
					polyline.esri_graphic = graphic;
				};

				var onError = function ( error ) {
					console.warn( "[MaximoSpatial] Error getting geometry to surround marker: ", error );
					if ( polyline.esri_graphic ) {
						providerPolylineLayer.remove( polyline.esri_graphic );
					}
					polyline.esri_graphic = null;

				};
				if ( this.esriGeometryService ) {
					this.esriGeometryService.buffer( params, onComplete, onError );
				}
			}
			var polygonOrLine = polyline.toProprietary();
			var graphic = null;
			var symbol = null;
			if ( polyline.closed && polyline.closed == true ) {
				// add a temporary graphic to have some data to return
				var fill = polyline.fillColor || "#000000";
				var _fillColor = new dojo.Color( fill );
				_fillColor.a = ( polyline.opacity || 1.0 );
				symbol = new esri.symbol.SimpleFillSymbol( esri.symbol.SimpleFillSymbol.STYLE_SOLID,
						new esri.symbol.SimpleLineSymbol( esri.symbol.SimpleLineSymbol.STYLE_SOLID,
								color, 3 ), _fillColor );

			} else {
				symbol = new esri.symbol.SimpleLineSymbol().setColor( color ).setWidth( polyline.width );
			}
			graphic = new esri.Graphic( polygonOrLine, symbol );
			providerPolylineLayer.add( graphic );
			polyline.esri_graphic = graphic;
			return graphic;
		},
		removeProviderPolyline : function ( polyline ) {
			var map = this.getProviderMap();

			var providerPolylineLayer = map.getLayer( "providerPolylineLayer" );

			if ( polyline.esri_graphic ) {
				providerPolylineLayer.remove( polyline.esri_graphic );
			} else {
				console.warn( "no graphics found on this polyline" );
			}
		},

		/* enables or disables the traffic layer */
		trafficLayer : null,
		setShowTraffic : function ( state ) {
			console.warn( "Traffic not implemented in this provider." );
		},

		latLng : function ( lat, lng, sr ) {
			return new MaximoSpatialLatLonPoint( {
				lat : lat,
				lng : lng,
				sr : sr,
				map : this
			} );
		},

		pointToProprietary : function ( point ) {
			return new google.maps.LatLng( point.lat, point.lng );
		},

		pointFromProprietary : function ( point ) {
			return this.latLng( point.lat(), point.lng(), null );
		},

		providerGeocode : function ( callback, errorCallback, key, address ) {
			this.showLoadingImg();
			var geocoder = new MaximoSpatialGeocoder( callback,
					errorCallback, {
						key : key,
						map : this,
						customParams : this.getGeoCoderConf()
					} );
			geocoder.geocode( {
				address : address
			} );
		},
		providerReverseGeocode : function ( callback, errorCallback, key, lat, lng ) {
			var geocoder = new MaximoSpatialGeocoder( callback,
					errorCallback, {
						key : key,
						map : this,
						customParams : this.getGeoCoderConf()
					} );
			geocoder.geocode( {
				lat : lat,
				lng : lng
			} );
		},
		createAutoLocateLabel : function ( labelText, labelPosition, labelFontSize, queryResultInfo ) {

			try {
				this.map.showLabels = true;
				var feature = queryResultInfo.features[ 0 ];
				if ( dojo.config.fwm.debug == true ) {
					console.log( "createAutoLocateLabel: ", labelText, labelPosition, labelFontSize );
				}

				var autoLocateLabel = new esri.symbol.TextSymbol( labelText );
				/* label font settings */
				var font = new esri.symbol.Font();
				font.setSize( labelFontSize + "pt" );
				autoLocateLabel.setFont( font );
				var xOffSet = 15;
				var yOffSet = 4;

				/* label alignment */
				var verticalAlignMent = labelPosition.charAt( 0 );
				switch ( verticalAlignMent ) {
					case "L":
						autoLocateLabel.setVerticalAlignment( "top" );
						yOffSet = -yOffSet;
						break;
					case "M":
						autoLocateLabel.setVerticalAlignment( "middle" );
						yOffSet = 0;
						break;
					case "U":
						autoLocateLabel.setVerticalAlignment( "bottom" );
						yOffSet = 3 * yOffSet;
						break;
				}
				var horizontalAlignMent = labelPosition.charAt( 1 );
				switch ( horizontalAlignMent ) {
					case "L":
						autoLocateLabel.setHorizontalAlignment( "right" );
						xOffSet = -xOffSet;
						break;
					case "R":
						autoLocateLabel.setHorizontalAlignment( "left" );
						break;
				}

				autoLocateLabel.setOffset( xOffSet, yOffSet );

				var geom = feature.geometry;
				var graphic = new Graphic( geom, autoLocateLabel );

				var labelLayer;
				if ( this.map.getLayer( "providerLabelLayer" ) === undefined ) {
					labelLayer = new esri.layers.GraphicsLayer( {
						id : "providerLabelLayer"
					} );
					this.map.addLayer( labelLayer );
				} else {
					labelLayer = this.map.getLayer( "providerLabelLayer" );

				}
				labelLayer.clear();
				labelLayer.add( graphic );

			} catch ( e ) {
				console.error( e );
			}
		},
		/**
		 * get the Position of the linked Mbo, or extent that has all the Mbos in case of Multiple Mbos
		 */
		_getMapInitialPosition : function () {
			var deferredInitialPosition = new dojo.Deferred();
			if ( this.mapConf.zoomToDataInput == true ) {
				if ( this.currentRecordMgr.hasAnyCoordinates() ) {

					console.log( "[Map] Get position of current MBO record " );
					this.getMboPosition( this.currentRecordMgr.mboInfo ).then(
							lang.hitch( this, function ( centerPoint ) {
								deferredInitialPosition.resolve( centerPoint );
							} ), lang.hitch(function(error) {
								var mboLayer = this.currentRecordMgr.mboInfo.layerInfoData[0].serviceName;
								if ( this.messageDiv ) {
									this.writeMessageInBox( this.messageDiv, "plussmap", "identifyQueryErrorDetail", [mboLayer, error.message], true );
								}
								console.error(error);
							}) );	
				} else {
					console.log( "[Map] Get Center when there are multiple records." );
					this.getMapExtentForMbos( this.currentRecordSetControl.mboInfoArray ).then(
							lang.hitch( this, function ( centerExtent ) {
								deferredInitialPosition.resolve( centerExtent );
							} ) );
				}
			} else {
				deferredInitialPosition.resolve( null );
			}
			return deferredInitialPosition.promise;
		},
		getLayerInfo : function ( mapServiceUrl ) {
			return esriRequest({
				url: mapServiceUrl,
				handleAs : "json",
				callbackParamName: "callback",
				content: {
					"f" : "json"
				},
				timeout: 30000
			} );
		},
		/**
		 * Get the center of the Mbo Based on the method centerOnMbo
		 */
		getMboPosition : function ( mboInfo ) {
			var mxRec = new MXRecord( {
				mboInfo : mboInfo,
				map : this
			} );
			var deferredReturn = new dojo.Deferred();
			mxRec.getGISPoint();
			var spatialAutolocate = this._isAutolocateBasedOnSpatial( mboInfo );
			// Added a condition to only enter this if clause if the record
			// is not an LBS record. LBS records must be handled by the base method
			if ( ( ( this._isBasedOnSpatial( mboInfo ) == true ) || ( spatialAutolocate == true ) )
					&& !mxRec.useLBSData() ) {
				var resolveQuery = function ( args ) {
					try {
						var updatedPoint = this._getMboPointInMap( mboInfo, args );
						queryDeferred.resolve( updatedPoint );
					} catch ( e ) {
						console.error( "No shape found in feature!", args, e );
						this.addWarningMessage("map", "linkedfeaturenoshapefound", null );
						queryDeferred.resolve();
					}
				};
				var queryDeferred = new dojo.Deferred();
				if ( spatialAutolocate == true ) {
					this._queryMapsServiceForMboGeometry( mboInfo.autolocate, dojo.hitch( this,
							resolveQuery ), dojo.hitch( this, function ( error ) {
						queryDeferred.reject();
					} ) );
					queryDeferred.then( lang.hitch( this, function ( point ) {
						deferredReturn.resolve( point );
					} ), lang.hitch( this, function ( error ) {
						deferredReturn.resolve();
					} ) );
				} else {
					this._queryMapsServiceForMboGeometry( mboInfo, dojo.hitch( this, resolveQuery ),
							dojo.hitch( this, function ( error ) {
								queryDeferred.reject();
							} ) );
					queryDeferred.then( lang.hitch( this, function ( point ) {
						deferredReturn.resolve( point );
					} ), lang.hitch( this, function ( error ) {
						deferredReturn.resolve();
					} ) );
				}
				return deferredReturn.promise;
			} else {
				var localgisdata = mxRec.getGISData();
				if ( mxRec.getAutolocateMboInfo() != null ) {
					localgisdata = mxRec.getAutolocateGISData();
				}
				if ( dojo.config.fwm.debug == true ) {
					console.log( "Center on  ", mboInfo.mxdata.mboName, localgisdata.lat,
							localgisdata.lng );
					console.log( "Is autolocated ", mboInfo.autolocate != null );
				}
				var point = this.latLng( localgisdata.lat, localgisdata.lng );

				if ( mxRec.useLBSData() ) {
					point = mxRec.getLBSPoint();
					point.sr = this.WGS84WKID;
					if(this.map!=null){
						var auxFct = function ( /* array of projected points */points ) {
						points[ 0 ].zoomlevel = zoomlevel;
						deferredReturn.resolve( points[ 0 ] );
						};
						this.getAllPointsFromWGS84( [
							point
						], dojo.hitch( this, auxFct ) );
					}else{
						deferredReturn.resolve(point);
					}	
				} else {
					// Adding a null check to make sure that the marker is only drawn if the coordinates
					// are not null.
					// The only possible scenario for this to happen is if the record is linked to a
					// spatial feature class
					// and after that the user tries to see the the record on another map provider.
					// There is a MXRecord.hasAnyCoordinates() check before the code reaches here, but,
					// if the record is
					// linked to a spatial feature class, that method will return true even if no GIS
					// lat/lng exist for the Maximo record
					if ( point.lat != null && point.lng != null ) {
						deferredReturn.resolve( point );
					}
				}
				return deferredReturn.promise;

			}

		},
		/**
		 * Function to move the Marker layer to the top.
		 */
		moveMarkerLayerToTop : function () {
			var mapInstance = this.map;
			var markerLayer = mapInstance.getLayer( "providerMarkerLayer" );
			var graphicLayersLength = mapInstance.graphicsLayerIds.length;
			if ( markerLayer && graphicLayersLength > 0 ) {
				mapInstance.reorderLayer( markerLayer, graphicLayersLength - 1 );
			}
		},
		/**
		 * Returns the initial extent when we have more than one Mbo associated
		 */
		getMapExtentForMbos : function ( mboInfoArray ) {
			var deferredMapExtentForMbos = new dojo.Deferred();
			if ( !mboInfoArray || mboInfoArray.length == 0 ) {
				deferredMapExtentForMbos.resolve( null );
				return deferredMapExtentForMbos.promise;
			}
			if ( mboInfoArray && mboInfoArray.length == 1 ) {
				this.getMboPosition( mboInfoArray[ 0 ] ).then( function ( point ) {
					deferredMapExtentForMbos.resolve( point );
				} );
			} else {
				deferredMapExtentForMbos.resolve( null );
			}
			return deferredMapExtentForMbos.promise;
		},
		/**
		 * Returns an extent based in the session's last user location
		 */
		_getLastUserLocation : function ( options ) {
			var mapInitialExtent;
			if ( options.lastUserLocationData && options.lastUserLocationData.customData
					&& options.lastUserLocationData.customData.extentData ) {
				var extent = options.lastUserLocationData.customData.extentData;
				var spatialReference = new SpatialReference( {
					wkid : extent.wkid,
					wkt : extent.wkt
				} );
				mapInitialExtent = new Extent( extent.xmin, extent.ymin, extent.xmax, extent.ymax,
						spatialReference );
			}
			return mapInitialExtent;
		},
		/**
		 * Returns the center of the features, given the query results
		 */
		_getMboPointInMap : function ( mboInfo, queryResultInfo, callback ) {
			if ( queryResultInfo.features && queryResultInfo.features[ 0 ] ) {
				var feature = queryResultInfo.features[ 0 ];

				if ( !feature ) {
					console.error( "feature is empty" );
					return null;
				}
				var point = this.getFeatureCenterPoint( feature );

				return point;
			} else {
				console.error( "no feature found!", queryResultInfo );
				throw "no feature found!";
			}
		},
		/**
		 * Refreshes the map dynamic layers
		 */
		refreshMap : function ( refreshOptions ) {
			var dynamicLayersIds = this.map.layerIds;
			
			/*
			 * Refresh Dynamic Layers
			 */
			dojo.forEach( dynamicLayersIds,  function ( id ) {

				var layer = this.map.getLayer( id );
				
				if ( layer instanceof esri.layers.DynamicMapServiceLayer ) {
					var layerDefinitionDeferred = new dojo.Deferred();
					layerDefinitionDeferred.then(layer.refresh);
					
					if (!refreshOptions || !refreshOptions.automatic) {
						var allLayerIds = dojo.map(layer.layerInfos, function(info) {
							return info.id;
						});
						this.updateLayerDefinitionsFromMaximo(id, allLayerIds, true).then(layerDefinitionDeferred.resolve);
					} else {
						layerDefinitionDeferred.resolve();
					}
				}
			}, this );
			
			/*
			 * Refresh GraphicsLayers
			 */

			dojo.forEach(this.map.graphicsLayerIds, function(id) {

				var layer = this.map.getLayer( id );
				
				if  (layer.url != null) {
					
					var currentSelectedObjectId;
					var graphicLayerDefinitionDeferred = new dojo.Deferred();
					graphicLayerDefinitionDeferred.then(function(layerRefreshed) {
						if (!layerRefreshed) {
							layer.refresh();
						}
						//select the current feature again
						if (currentSelectedObjectId) {
							
							var layerQuery = new Query();
							query.where = layer.objectIdField + " = '" + currentSelectedObjectId + "'"; 
							
							layer.selectFeatures(query, FeatureLayer.SELECTION_NEW);
						}
					});
					
					/*
					 *Get the Objectid of the currently selected feature for the layer 
					 */
					var currentSelectedObjects = layer.getSelectedFeatures();
					if (currentSelectedObjects.length > 0) {
						currentSelectedObjectId = currentSelectedObjects[0].attributes[layer.objectIdField];
						layer.clearSelection();
					}

					if (!refreshOptions || !refreshOptions.automatic ) {

						var layerRefreshed =  false;


						this.updateLayerDefinitionsFromMaximo(id, layer.layerId).then(dojo.hitch(this, function(layerIdsRefreshed) {
							layerRefreshed = (layerIdsRefreshed.indexOf(layer.layerId) > -1) ? true : false;
							graphicLayerDefinitionDeferred.resolve(layerRefreshed);
						}));
					} else {
						graphicLayerDefinitionDeferred.resolve(false);
					}
				}
			}, this);
			
			this.inherited( arguments );
		},
		writeMessageInBox : function ( messageDiv, msgGroup, msgKey, params, isError ) {
			if ( !params ) {
				params = [];
			}
			var formatDateNumber = function ( numberLength, number ) {
				var zerosToAdd = numberLength - number.toString().length;
				if ( zerosToAdd > 0 ) {
					for ( var i = 0; i < zerosToAdd; i++ ) {
						number = "0" + number;
					}
				}
				return number;
			}
			var message = i18n.getMaxMsgWithParams( msgGroup, msgKey, params );
			message = message.split( "\\n" ).join( "<br/>" );
			var currentdate = new Date();
			var hourString = formatDateNumber( 2, currentdate.getHours() );
			var minutesString = formatDateNumber( 2, currentdate.getMinutes() );
			var secondsString = formatDateNumber( 2, currentdate.getSeconds() );
			var milisecondsString = formatDateNumber( 3, currentdate.getMilliseconds() );
			var dateString = hourString + ":" + minutesString + ":" + secondsString + "."
					+ milisecondsString;
			if ( isError ) {
				messageDiv.innerHTML += "[" + dateString + " ] " + "<span style='color:"
						+ this.messageBoxErrorColor + "'>" + message + "</span> </br>";
				console.error(message);
			} else {
				messageDiv.innerHTML += "[" + dateString + " ] " + message + "<br/>";
				console.log(message);
			}

			messageDiv.scrollTop = messageDiv.scrollHeight;
		},
		createLoadingImage: function() {
			var loadImg = dojo.create(
				"img", 
				{
					"class": "", 
					"src": dojo.config.fwm.ctxRoot + "/webclient/images/pluss/loading_spatial.gif",
				}
			);
			
			return loadImg;
		},
		/**
		 * Creates the loading icon for ongoing operations
		 * and creates the functions to show and hide the icon
		 * 
		 * @param divId
		 */
		setMapLoadingImage: function(divId) { 
			//only if the map is already created
			if (this.map) {
				var loadImg = this.createLoadingImage();
				dojo.style(loadImg, {
					"position": "absolute",
					"left": "0px",
					"top": "0px",
				});

				//place the icon in the map div Id
				dojo.place(loadImg, dojo.byId(divId), "last");
				
				esri.hide(loadImg);
				this._loadImg = loadImg;
								
			} 
		},
		/**
		 * Show the loading icon, if it was already created
		 */
		showLoadingImg: function() {
			if (this._loadImg) {
				var dx = 30;
				var dy = 110;
			    domAttr.set(this._loadImg, 'style', "position:absolute; left:"+dx+"px; top:"+dy+"px; ");
				esri.show(this._loadImg);
			}
		},
		/**
		 * Hide the loading icon, if it was already created
		 */
		hideLoadingImg: function() {
			if (this._loadImg) {
				esri.hide(this._loadImg);
			}
		},
		/**
		 * 
		 * Get the mapConf info for layer from a url
		 * 
		 * @param the layer url
		 * @param the type of info to be returned, "mapService" or "mapSeriviceLayer")
		 * @return the config
		 */
		getMapConfInfoFromURL: function(url, infoType) {
			var returnInfo;
			if (!url) {
				return null;
			}
			
			dojo.forEach(this.mapConf.SPATIAL.mapservices, function(service) {
				var serviceURL = service.url;
				dojo.forEach(service.serviceLayers, function(layerInfo) {
					var serviceLayerUrl = serviceURL + "/" + layerInfo.layerid;
					if (serviceLayerUrl === url) {
						if (!infoType  ||infoType  == "mapService" ) {
							returnInfo = service;
						} else if (infoType == "mapServiceLayer") {
							returnInfo = layerInfo;
						}
					}
				});
			});
			return returnInfo;

		},
		/**
		 * @param mapServiceName 
		 * @param layerId 
		 * @return the map service/map service layer configuration
		 */
		getMapConfInfoFromNameAndId: function(mapServiceName, layerId) {
			var returnInfo;
			
			var mapServiceInfo = this.mapConf.SPATIAL.mapservices.find(function(serviceInfo) {
				return serviceInfo.name == mapServiceName;
			});
			
			if (layerId == null) {
				returnInfo =  mapServiceInfo;
			} else {
				if (mapServiceInfo && mapServiceInfo.serviceLayers && (mapServiceInfo.serviceLayers.length > 0) ) {
					returnInfo = mapServiceInfo.serviceLayers.find(function(layerInfo) {
						return layerInfo.layerid == layerId;
					});
				}
			}
			return returnInfo;
		},
		getMapServiceConfigInfoFromURL: function(url) {
			return this.getMapConfInfoFromURL(url, "mapService");
		},
		getMapServiceLayerConfigInfoFromUrl: function(url) {
			return this.getMapConfInfoFromURL(url, "mapServiceLayer");
		},
		/**
		 * @param url The url of the Service Layer
		 * @param mapConf The map configuration from Map Manager
		 * 
		 * @return The name of the Service that contains the service layer
		 */
		getServiceNameFromServiceLayerURL: function(url) {
			var mapServiceConf = this.getMapServiceConfigInfoFromURL(url);
			return (mapServiceConf) ?  mapServiceConf.name : null;
		},
		/**
		 * @param url The url of the Service Layer
		 * @param mapConf The map configuration from Map Manager
		 * 
		 * @return The url of the Service that contains the service layer
		 */
		getServiceURLFromServiceLayerURL: function(url) {
			var mapServiceConf = this.getMapServiceConfigInfoFromURL(url);
			return (mapServiceConf) ? mapServiceConf.url : null;
		},
		destroyRecursive: function() {
			if (this.map.spatialMapManager) {
				this.map.spatialMapManager.cancelMapLoad()
			}
			this.inherited(arguments);
		},
		addWarningMessage: function(group, key, params) {
			if (!this.warningMessagesArray) {
				this.warningMessagesArray = [];
			}
			this.warningMessagesArray.push({
				"group": group,
				"key": key,
				"params": params
			});
		},
		showMessagesFromArray: function() {
			dojo.forEach(this.warningMessagesArray, function(warningMessageObject) {
				this.showWarningMessage(warningMessageObject.group, warningMessageObject.key, warningMessageObject.params);
			}, this);
			this.warningMessagesArray = [];
		},
		/**
		 * 
		 * @param serviceName
		 * @param mapServiceLayerId
		 * @param mapLayerId
		 */
		updateLayerConfDefinition: function(serviceName, mapServiceLayerIds) {
			var deferred = new dojo.Deferred();
			this.getMaximo().generateUpdatedLayerDefinition(serviceName, mapServiceLayerIds, dojo.hitch(this, function(data) {
				if (data && data.result == "success" && data.layerDefinitions)  {
					dojo.forEach(Object.keys(data.layerDefinitions), function(layerId) {
						this.mapConf.mapServiceDefinitions[serviceName][layerId] = data.layerDefinitions[layerId];
					}, this);
					deferred.resolve(data.layerDefinitions);
				} else {
					deferred.reject();
				}
			}));
			return deferred.promise;
		},
		/**
		 * 
		 * @param mapServiceName the map service name
		 * @return array with definition of layers that need to have features filetered
		 */
		generateLayerDefinitionsArray: function(mapServiceName) {

			var dynamicLayerDefinitions = [];
			
			var layerDefinitions = this.mapConf.mapServiceDefinitions;
			if (layerDefinitions) {
				var mapServiceDefinitions = layerDefinitions[mapServiceName];
				if (mapServiceDefinitions) {
					dojo.forEach(Object.keys(mapServiceDefinitions), function(key) {
						dynamicLayerDefinitions[key] = mapServiceDefinitions[key];
					}, this);
				}
			}
			
			return dynamicLayerDefinitions;
			
		},
		/**
		 * 
		 * Find if the layer is a Feature Layercreated by EditTool, or is a feature layer from webmap, or is a dynamic layer
		 * 
		 * @param id
		 * @return
		 */
		findLayerConfType: function(id) {
		
			var layerType;
			
			var layer = this.map.getLayer(id);
			if (layer.type == "Feature Layer") { 
				if (layer.dynamicLayer && (layer.id.indexOf("EditToolFeature") > -1)) {
					layerType = "EditToolFeaturelayer";
				} else {
					layerType = "WebMapFeatureLayer";
				}
			} else {
				layerType = "DynamicLayer";
			}
			
			return layerType;
			
		},
		/**
		 * 
		 * @param idOfLayer the id of the layer in the map to have definition updated
		 * @param layerId the layerId, that is, the number of the layer in the server
		 * @param noDynamicLayerRefresh do not refresh the dynamic layer after definition updated if true
		 * @return an array with the layerIds that had the definitionupdated
		 */
		updateLayerDefinitionsFromMaximo: function(mapIdOfLayer, layerIds, noDynamicLayerRefresh ) {
			var deferred = new dojo.Deferred();
			
			if (mapIdOfLayer == null || layerIds == null) {
				deferred.reject();
				return deferred.promise;
			}
			
			if (!Array.isArray(layerIds)) {
				layerIds = [layerIds];
			}

			var layer = this.map.getLayer(mapIdOfLayer);
			if (!layer) {
				deferred.resolve([]);
				return deferred.promise;
			}

			var layerConfType = this.findLayerConfType(mapIdOfLayer);
			
			/*
			 * If the layer was created buy edit tool, we need to find the corresponding layer
			 * in the Map Service Table
			 */
			var mapServiceConf;
			
			if (layerConfType == "EditToolFeaturelayer") {
				var layerUrl = layer.dynamicLayer.url + "/" + layer.layerId;
				mapServiceConf = this.getMapServiceConfigInfoFromURL(layerUrl);
			} else if (layerConfType == "WebMapFeatureLayer")  {
				mapServiceConf = this.getMapServiceConfigInfoFromURL(layer.url);
			} else {
				//dynamic layer
				
				mapServiceConf = this.mapConf.SPATIAL.mapservices.find(function(mapService) {
					return mapService.url == layer.url;
				});
				
			}
			
			if (!mapServiceConf) {
				deferred.resolve([]);
				return deferred.promise;
			}
			
			//Use only the ids that need to be filtered
			var layerIdsToFilter = dojo.filter(layerIds, function(id) {
				var mapServiceLayerConf = mapServiceConf.serviceLayers.find(function(serviceLayerConf) {
					return serviceLayerConf.layerid == id;
				});
				return (mapServiceLayerConf && mapServiceLayerConf.hasToFilterFeatures);
			});
			var mapServiceName = mapServiceConf.name;
			
			if (layerIdsToFilter.length > 0) {
				this.updateLayerConfDefinition(mapServiceName, layerIdsToFilter ).then(dojo.hitch(this, function(layerDefinitions) {
					if (layerConfType == "EditToolFeaturelayer" ) {
						layer.setDefinitionExpression(layerDefinitions[layerIdsToFilter[0]]);
						var dynamicLayer = layer.dynamicLayer;
						var newDefinitionsArray = this.generateLayerDefinitionsArray(mapServiceName);
						dynamicLayer.setLayerDefinitions(newDefinitionsArray, noDynamicLayerRefresh);
					} else if (layerConfType == "WebMapFeatureLayer") {
						layer.setDefinitionExpression(layerDefinitions[layerIdsToFilter[0]]);
					} else if (layerConfType == "DynamicLayer") {
						var newDefinitionsArray = this.generateLayerDefinitionsArray(mapServiceName);
						layer.setLayerDefinitions(newDefinitionsArray);
					}
					deferred.resolve(layerIds);
				}), function(error) {
					var errorParams = [];
					for (var i =0; i< Object.keys(error).length; i++) {
						var param = "msgParams"+i;
						if (error.hasOwnProperty(param)) {
							errorParams.push(error[param]);
						}
					}
					deferred.reject();
					this.getMaximo().showMessage( error.msgGroup, error.msgKey, errorParams );
				});	
			} else {
				deferred.resolve([]);
			}
			return deferred.promise;
		},
		removeMboMarker: function(mboInfo, layerId) {
			this.inherited(arguments);
			this.removeMboHighligh(mboInfo);
		},

		loadMapLegends: function( map ) {
			var legendDiv = dojo.create( "div", {  
				"id": "mapLegend",
				"style": {
					"visibility": "hidden", // cannot use display: none because it breaks legends that use svg
					"height": "0",
				},
			} );
			var mapContainer = map.container;

			dojo.place( legendDiv, mapContainer, "first");

			this.legend = Legend( 
				{ 
					map,
					respectCurrentMapScale: false,
					autoUpdate: false, // should call this.legend.refresh to update legend
					respectVisibility: false,
				}, 
				legendDiv
			);
			this.legend.startup();

			this.legendMutationObserver = new MutationObserver( function() {
				dojo.publish("MapLegendsUpdated");
			} );
			this.legendMutationObserver.observe( legendDiv, { childList: true, subtree: true } );
		},

		getLayerLegendDiv: function ( layerId, subLayerId ) {
			var layerLegendId = `${this.legend.id}_${layerId}`;

			if (subLayerId !== undefined) {
				layerLegendId += `_${subLayerId}`;
			}

			var legendDiv = dojo.byId( layerLegendId );

			if ( !legendDiv ) {
				return null;
			}

			return dojo.clone( legendDiv );
		},

		destroyMapLegends: function () {
			if ( !this.legend ) {
				return;
			}

			this.legend.destroy();
			this.legendMutationObserver.disconnect();
		},

		getAllLayersIds: function ( map ) {
			var layerIds = map.layerIds || [];
			var graphicsLayerIds = map.graphicsLayerIds || [];

			return layerIds.concat( graphicsLayerIds );
		},

		getMapLayers: function ( map ) {
			var layerIds = this.getAllLayersIds( map );
			var layers = dojo.map( layerIds, function ( layerId ) {
				return map.getLayer( layerId );
			} );

			return layers;
		},

		getBasemaps: function ( map ) {
			var basemaps = [];
			var allLayersIds = this.getAllLayersIds( map );

			dojo.forEach( allLayersIds, function ( layerId ) {
				var layer = map.getLayer( layerId );

				if ( layer.isBasemap ) {
					basemaps.push( layer );
				}
			}, this );

			return basemaps;
		},

		getBasemapsIds: function ( map ) {
			var basemaps = this.getBasemaps( map );
			var basemapsIds = [];

			dojo.forEach( basemaps, function(basemap) {
				basemapsIds.push( basemap.id );
			}, this );

			return basemapsIds;
		},

		buildLayerQuery: function ( layer, options = { useDefinitionExpression: true } ) {
			var useDefinitionExpression = options.useDefinitionExpression;

			var query = new Query();
			query.where = '';

			if (useDefinitionExpression && layer.getDefinitionExpression) {
				var definitionExpression = layer.getDefinitionExpression() || '';

				query.where = definitionExpression;
			}

			return query;
		},

		getSpatialLayersToolLayersConfigurations() {
			if ( 
				!this.toolsJson || 
				!this.toolsJson.SpatialLayersTool || 
				!this.toolsJson.SpatialLayersTool.customJson ||
				!this.toolsJson.SpatialLayersTool.customJson.layers
			) {
				return null;
			}

			return this.toolsJson.SpatialLayersTool.customJson.layers;
		},

		getLayerPersistedAttribute: function ( layer, attribute = '' ) {
			var layersConfigurations = this.getSpatialLayersToolLayersConfigurations();
			if ( !layersConfigurations ) {
				return null;
			}

			var layerId = layer.id;
			if ( 
				layersConfigurations[ layerId ] !== undefined && 
				layersConfigurations[ layerId ][attribute] !== undefined
			) {
				return layersConfigurations[ layerId ][attribute];
			}

			return null;
		},

		getLayerPersistedVisibility: function ( layer ) {
			return this.getLayerPersistedAttribute( layer, 'visible' );
		},

		getLayerPersistedVisibleLayers: function ( layer ) {
			return this.getLayerPersistedAttribute( layer, 'visibleLayers' );
		},

	});
	
});

